<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.maleperformance-news.com/rln/v1/network/terms.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Sep 2019 18:54:51 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=iso-8859-1" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<meta name="googlebot" content="NOINDEX, NOFOLLOW">
    <meta name="description" content="">
    <meta name="author" content="">
<title>Terms & Conditions</title>
	<link rel="stylesheet" type="text/css" href="https://www.maleperformance-news.com/rln/v1/network/css/pre-defined.css"> <!--- CSS Reset and Pre Defined -->
	<link rel="stylesheet" type="text/css" href="https://www.maleperformance-news.com/rln/v1/network/css/cart.css"> <!--- Main Custom CSS -->
	<!--- core CSS and favicon-->
<style type="text/css">
<!--
#red16bold {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    font-size: 16px;
    color: #f00;
    font-weight: bold;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	font-weight: bold;
	color: #F00;
}
.style3 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	font-weight: bold;
	color: #F00;
}
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
.terms_1_1{
	text-align: center;
	padding-top: 10px;
}
-->
</style>

</head><!--/head-->

<body>

		<div id="site-wrap">

		  <div id="body-wrapper">
				<div id="content">

						<section id="alpha-header">
							
						</section>

						<section id="cart-content" class="third-step">
							<div class="inner-wrap py clearfix">
    <div id="red16bold">TERMS AND CONDITIONS OF USE</div>
  <hr />
		
              <p class="style3"><strong>CAREFULLY READ AND UNDERSTAND THESE TERMS BEFORE ORDERING ANY PRODUCT THROUGH THIS WEBSITE</strong></p>
              <p><span id="black16bold">ATTENTION:</span><span class="style2">&nbsp;This is a legal agreement (the "Agreement") between You, the individual, company or organization ("you," "your," or "Customer") and  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> ("we," "our", "Company" or " <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>" By ordering, accessing, using or purchasing  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> ("Product") through this website or related websites (collectively the "Website"), you are agreeing to be bound by, and are becoming a party to, this Agreement. We may at our sole and absolute discretion change, add, modify, or delete portions of this Agreement at any time without notice. It is your sole responsibility to review this Agreement for changes prior to use of the Website or purchase of the Product.</span></p>
              <p id="black16bold">IT IS STRONGLY RECOMMENDED THAT YOU REVIEW THIS DOCUMENT IN ITS ENTIRETY BEFORE ACCESSING, USING OR BUYING ANY PRODUCT THROUGH THE WEBSITE</p>
              <p class="style1">Terms and Conditions</p>
                <p><span class="style2">Please carefully read the following terms and conditions as when you purchase any of the products from our web site ( <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> you agree and are bound to the following terms and conditions. Your order will not be processed unless you check the box near the terms and conditions signifying that you have read and agreed to the terms. &nbsp;<br>
                <br>
                This Agreement is between  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> and you ("you" or "Customer") This Section sets forth the terms and conditions which apply to the use by you of the website ( <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> (as defined below) and any other subscription product or service offered for sale by  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> and/or its affiliates (collectively, " <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> ").<br><br>
			The right to use any product or service offered by  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> is personal to you and is not transferable to any other person or entity.  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> reserves the right to make changes to the website ( <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>), policies, and these terms at any time without notice.</span></p>
              <p class="style1">1.  Sample Offer Terms</p>
                <p class="style2">Sample Offer is designed to display the quality and effectiveness of the  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> product. This gives you the opportunity to try this remarkable program for just the cost of shipping and handling so you can come to a decision for yourself if this is the right product for you. <br><br>
		Upon ordering, you agree to pay <strong>$6.97 shipping and handling</strong> for the sample bottle as well as agree to enrollment in the Customer Preferred Program. If you are enjoying the product do nothing and in <strong>14 days</strong> from the date you purchased you will be charged the low rate of <strong>$119.97</strong> for the product you received. Approximately 30 days and every <strong>30 days thereafter</strong> you will be sent another fresh 1 month supply of  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> (1 bottle) and your credit card on file will be billed the Member's Discount rate price of just <strong>$119.97</strong> per bottle plus <strong>$9.97</strong> shipping and handling. That is a savings of over 30% the regular price of a 1 month supply of  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>.<br><br>
		Please remember that most customers see noticeable results after using this product consistently for at least 3 months.By being an exclusive member of our Customer Preferred Program, you will be entitled to receive special offers and promotions from us and our 3rd party partners that only our Customer Preferred Program members receive.<br><br>
		You are not obligated to remain in the program after you receive your Sample Offer of  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> and you can <strong>cancel anytime</strong> within the 14 day period before you receive your 30 day supply bottle or anytime thereafter by contacting  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> Customer Care.<br><br>
		<strong>To avoid being charged for your 30 day monthly supply, you must cancel your enrollment before your sample offer period is over.</strong> You may cancel your enrollment by calling <strong><span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=1-855-204-4869&amp;c=ph" /></span></strong> Monday thru Friday 9am-5pm Eastern Standard Time or contact our support department at <strong><span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span>.</strong><br><br>
		
		</p>
              <p class="style1">2.  Return Policy</p>
                <p class="style2">You have <strong>30 days</strong> to request a refund after you receive your order. Refunds are not given for sample bottles. Please contact Customer Care to initiate the return process. You will be refunded for each unopened unit you send back to us only. You will need to send in the unopened unit back to the address provided below. Upon receipt you will receive a refund of purchase price <strong>minus shipping and handling and a 35% restocking fee.</strong> Refused or returned packages that are sent to us without prior approval from Customer Care are not eligible for a refund.</p>
              <p class="style1">Return Address</p>
              <p class="style2"><span style="position:relative;top:4px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Fulfillment%20Center" /><br><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=C/O%20Male%20Enhancement%20Formula" /><br><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=P.O.%20Box%20153201%20Suite%201093" /><br><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Tampa,%20FL%2033684" /></span><br><br>
We are not responsible for lost or stolen items. We recommend all returned items to be sent using some type of delivery confirmation system to ensure proper delivery. <br><br>
After the shipping department receives your return, it generally takes 7 business days or sooner to process your refund. Once a return is processed, it usually takes 3-5 business days for the return to be posted to your account, depending on your financial institution.
</p>
              <p class="style1">3.  Negative Option Clause </p>
              <p class="style2">THIS CONSUMER TRANSACTION INVOLVES A NEGATIVE OPTION, AND THAT YOU MAY BE LIABLE FOR PAYMENT OF FUTURE GOODS AND SERVICES UNDER THE TERMS OF THIS AGREEMENT FOR $119.97 PLUS $9.97 SHIPPING AND HANDLING PER MONTH IF YOU FAIL TO NOTIFY THE SUPPLIER NOT TO SUPPLY THE GOODS OR SERVICES DESCRIBED.</p>
              <p class="style1">4.  Billing Support</p>
			
			<p class="style2">Please contact  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> Customer Care by email or phone for any billing issues you may have.<br><br>
			Toll Free Customer Care: <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=1-855-204-4869&amp;c=ph" /></span><br>
Customer Care: <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span><br>
Hours: M-F 9AM-5PM EST
</p>
			
			
              <p class="style1">5.Order Acceptance and Decline</p>
                <p><span class="style2">Your receipt of an electronic or other form of order confirmation does not signify our acceptance of your order, nor does it constitute confirmation of our offer to sell. We reserve the right at any time after receipt of your order to accept, decline, or limit your order for any reason, whether or not your credit card has been charged. If your credit card has been charged and your order has been declined, you will receive a prompt refund credit to your account. <br><br>

We make every effort to maintain the availability of our Site. However, should we experience technical difficulties, we are not responsible for orders that are not processed or accepted. 

                </span>
		</p>
                  <p class="style1">6.  Fees and Taxes</p>
		   <p class="style1">6.1 Fees</p>
                <p><span class="style2">You shall pay the costs listed for the products and services you purchase on the Site, in accordance with these Terms. We may change the fees for its products and services from time to time. Unless otherwise stated, all fees are quoted in U.S. Dollars. </span></p>
              <p class="style1">6.2 Payment Terms</p>
                <p class="style2">We will debit all fees payable by You to  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> directly from the credit card account designated by You when You purchase products or services on the Site.<br><br>

You agree to provide us with accurate and complete billing information, including valid credit card information, your name, address and telephone number, and to provide us with any changes in such information within 15 days of the change.<br><br> 

You agree that we may, at our sole discretion, suspend or terminate your purchases on the Site if, for any reason, your credit card company refuses to pay the amount billed for the service. You also agree that we may, at our sole discretion, require you to pay any outstanding balance or overdue amount by means acceptable to us. If legal action becomes necessary for us to collect on balances due, you agree to reimburse us for all expenses incurred to recover sums due, which may include reasonable attorney fees and other legal expenses. <br><br>

Terms of payment are within our sole discretion and, unless otherwise agreed by us in writing, payment must be received by us prior to our acceptance of an order. <br><br>

We accept VISA and MASTERCARD for all purchases. You represent and warrant that (i) the credit card information you supply to us is true, correct and complete, (ii) charges incurred by you will be honored by your credit card company, and (iii) you will pay charges incurred by you at the posted prices, including all applicable taxes, if any. 
</p>
              <p class="style1">6.3 Taxes</p>
              <p class="style2">All fees under this Agreement exclude all applicable sales, use, and other taxes and government charges, whether federal, state or foreign, and You will be responsible for payment of all such taxes (other than taxes based on  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>&#8217;s income), fees, duties, and charges, and any related penalties and interest, arising from the payment of any and all fees under these Terms. </p>
                <p><span class="style1">7. Changes in Products and Pricing</span></p>
              <p class="style2">We reserve the right to discontinue products and services at its sole discretion at any time without notice to You. To the extent that  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> provides information on availability of products or services, You should not rely on such information, and we will not be liable for any lack of availability of products or services that You may order through the Site. <br><br>

All pricing for the products and services available on the Site is subject to change. For all of our prices and products, we reserve the right to make adjustments due to changing market conditions, product discontinuation, manufacturer price changes, errors in advertisements and other extenuating circumstances. 
</p>
               
              <p class="style1">Herbal Safety 
			Guidelines</p>
              <p class="style2">Before using an herb you are unfamiliar with, find out its medicinal properties. Research it thoroughly and/or consult with an appropriately qualified practitioner or expert. If you are taking prescription drugs, or have a medical condition, check with an appropriately qualified practitioner before using herbs for health purposes. For maximum effectiveness, herbs must be used according to product dosage and other instructions. For example, consuming a greater amount than the recommended dosage may not produce better results.. As individuals we all have different constitutions, sensitivities, allergic reactions and possible health conditions. The following are some guidelines for using herbs, including the ones offered on our websites. </p>
              <p class="style1">Should I check with my doctor or healthcare provider before using a supplement?</p>
                <p class="style2">This is a good idea, especially for certain population groups. Dietary supplements may not be risk-free under certain circumstances. If you are pregnant, nursing a baby, or have a chronic medical condition, such as, diabetes, hypertension or heart disease, be sure to consult your doctor or pharmacist before purchasing or taking any supplement. While vitamin and mineral supplements are widely used and generally considered safe, you may wish to check with your doctor or pharmacist before taking these or any other dietary supplements. If you plan to use a dietary supplement in place of drugs or in combination with any drug, tell your health care provider first. Many supplements contain active ingredients that have strong biological effects and their safety is not always assured in all users. If you have certain health conditions and take these products, you may be placing yourself at risk.</p>
              <p class="style1">Some supplements may interact with prescription and over-the-counter medicines.</p>
                <p class="style2">Taking a combination of supplements or using these products together with medications (whether prescription or OTC drugs) could under certain circumstances produce adverse effects. Be alert to advisories about these products, whether taken alone or in combination. For example: Coumadin (a prescription medicine), ginkgo biloba (an herbal supplement), aspirin (an OTC drug) and vitamin E (a vitamin supplement) can each thin the blood, and taking any of these products together can increase the potential for internal bleeding.  Consult with your physician or other health care provider about any possible adverse interactive effects involving supplements and medications that you may be taking. </p>
              <p class="style3">Some supplements can have unwanted effects during surgery.</p>
                <p class="style2">It is important to fully inform your doctor about the vitamins, minerals, herbals or any other supplements you are taking, especially before elective surgery. You may be asked to stop taking these products at least 2-3 weeks ahead of the procedure to avoid potentially dangerous supplement/drug interactions -- such as changes in heart rate, blood pressure and increased bleeding - that could adversely affect the outcome of your surgery.</p>
              <p class="style1"> 9.  Legal Disclaimer</p>
                <p class="style2">Statements made by  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> have not been evaluated by the food and drug administration. The FDA does not evaluate or test herbs. These products are not intended to diagnose, treat, cure or prevent any illness or disease. Consult with your physician for diagnosis or treatment. Use herbs as per instructions and always watch for any allergic reactions.
		<br><br>
The information presented on this site is not presented with the intention of diagnosing any disease or condition or prescribing any treatment. It is offered as information only, for use in the maintenance and promotion of good health in cooperation with a licensed medical practitioner. <br><br>
In the event that any individual should use the information presented on this website without a licensed medical practitioner's approval, that individual will be diagnosing for him or herself.<br><br>
No responsibility is assumed by  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>, the author, publisher or distributors of this information should the information be used in place of a licensed medical practitioner's services.<br><br>
No guarantees of any kind are made for the performance or effectiveness of the products or ingredients mentioned on this website. Furthermore, this information is based solely on the traditional and historic use of a given herb, or on clinical trials that are generally not, or may not be, recognized by any US government agency or medical organization.<br><br>
This information has not been evaluated or approved by the US Food and Drug Administration for the diagnosis, treatment or cure of any illness or disease,, nor has it gone through the rigorous double-blind clinical trials required before a particular product can be deemed truly beneficial and safe and prescribed for the treatment of any condition or disease. 
</p>
    <p class="style1">10.  Limitation of Liability </p>
     <p class="style2"> <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> neither endorses nor is responsible for the accuracy or reliability of any opinion, advice or statement on the website ( <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>). Under no circumstances will  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> be liable for any loss or damage caused by your reliance on information obtained through the content on the website ( <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>). It is your responsibility to evaluate the accuracy, completeness or usefulness of any information, opinion, advice or other content available through the website ( <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>). Please seek the advice of professionals, as appropriate, regarding the evaluation of any specific information, opinion, advice or other content, including but not limited to financial, health, or lifestyle information, opinion, advice or other content.<br><br>
     IN NO EVENT SHALL  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>, ITS SUPPLIERS, OR SERVICE PROVIDERS, OR THEIR OFFICERS, DIRECTORS, EMPLOYEES, CONTRACTORS OR AGENTS BE LIABLE FOR LOST PROFITS OR ANY SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR IN CONNECTION WITH THE SOFTWARE, THE ADDITIONAL SOFTWARE, THE PRODUCTS AND SERVICES OR THIS AGREEMENT (HOWEVER ARISING, INCLUDING NEGLIGENCE).  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>, ITS SUPPLIERS', AND SERVICE PROVIDERS', CUMULATIVE LIABILITY, AND THE LIABILITY OF THEIR OFFICERS, DIRECTORS, EMPLOYEES, CONTRACTORS AND AGENTS TO YOU OR ANY THIRD PARTIES IN ANY CIRCUMSTANCE IS LIMITED TO THE GREATER OF: (A) THE AMOUNT OF FEES YOU PAY TO  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>  FOR (I) PRODUCTS AND SERVICES PURCHASED ON ITS WEBSITE AND (II) ONE HUNDRED U.S. DOLLARS (U.S. $100). 
<br><br>
SOME JURISDICTIONS PROHIBIT THE EXCLUSION OR LIMITATION OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES, SO THE ABOVE LIMITATIONS MAY NOT APPLY TO YOU. 
</p>
      <p class="style1">11.  Disclaimer of Warranties </p>
 <p class="style2">ALL MATERIALS AND SERVICES ON THIS SITE ARE PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR FOR THE WARRANTY OF NON-INFRINGEMENT. WITHOUT LIMITING THE FORGOING, WE MAKE NO WARRANTY THAT (A) THE SERVICES AND MATERIALS WILL MEET YOUR REQUIREMENTS, (B) THE SERVICES AND MATERIALS WILL BE UNINTERRUPTED, TIMELY, SECURE, OR ERROR-FREE, (C) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SERVICES OR MATERIALS WILL BE ACCURATE OR RELIABLE, OR (D) THE QUALITY OF ANY PRODUCTS, SERVICES, OR INFORMATION PURCHASED OR OBTAINED BY YOU FROM THE SITE FROM US OR OUR AFFILIATES WILL MEET YOUR EXPECTATIONS OR BE FREE FROM MISTAKES, ERRORS, OR DEFECTS. <br><br>

THIS SITE MAY INCLUDE TECHNICAL OR OTHER MISTAKES, INACCURACIES OR TYPOGRAPHICAL ERRORS. WE MAY MAKE CHANGES TO THE MATERIALS AND SERVICES AT THIS SITE, INCLUDING BUT NOT LIMITED TO THE PRICE STRUCTURE AND DESCRIPTIONS OF ANY PRODUCTS LISTED HEREIN, AT ANY TIME WITHOUT NOTICE. THE MATERIALS OR SERVICES AT THIS SITE MAY BE OUT OF DATE, AND WE MAKE NO COMMITMENT TO UPDATE SUCH MATERIALS OR SERVICES. <br><br>

THE USE OF THE SERVICES OR THE DOWNLOADING OR OTHER ACQUISITION OF ANY MATERIALS THROUGH THIS SITE IS DONE AT YOUR OWN DISCRETION AND RISK AND WITH YOUR AGREEMENT THAT YOU WILL BE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT RESULTS FROM SUCH ACTIVITIES. <br><br>

THROUGH YOUR USE OF THE SITE, YOU MAY HAVE THE OPPORTUNITIES TO ENGAGE IN COMMERCIAL TRANSACTIONS WITH OTHER USERS AND VENDORS. YOU ACKNOWLEDGE THAT ALL TRANSACTIONS RELATING TO ANY MERCHANDISE OR SERVICES OFFERED BY ANY PARTY, INCLUDING, BUT NOT LIMITED TO THE PURCHASE TERMS, PAYMENT TERMS, WARRANTIES, GUARANTEES, MAINTENANCE AND DELIVERY TERMS RELATING TO SUCH TRANSACTIONS, ARE AGREED TO SOLELY BETWEEN THE SELLER OR PURCHASER OF SUCH MERCHANDISE AND SERVICES AND YOU. WE MAKE NO WARRANTY REGARDING ANY TRANSACTIONS EXECUTED THROUGH, OR IN CONNECTION WITH THIS SITE, AND YOU UNDERSTAND AND AGREE THAT SUCH TRANSACTIONS ARE CONDUCTED ENTIRELY AT YOUR OWN RISK. ANY WARRANTY THAT IS PROVIDED IN CONNECTION WITH ANY PRODUCTS, SERVICES, MATERIALS, OR INFORMATION AVAILABLE ON OR THROUGH THIS SITE FROM A THIRD PARTY IS PROVIDED SOLELY BY SUCH THIRD PARTY, AND NOT BY US OR OUR AFFILIATES. 
<br><br>
CONTENT AVAILABLE THROUGH THIS SITE OFTEN REPRESENTS THE OPINIONS AND JUDGMENTS OF AN INFORMATION PROVIDER, SITE USER, OR OTHER PERSON OR ENTITY NOT CONNECTED WITH  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>. WE DO NOT ENDORSE, NOR ARE WE RESPONSIBLE FOR THE ACCURACY OR RELIABILITY OF SUCH OPINION, ADVICE, OR STATEMENT. <br><br>

SOME STATES OR JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF CERTAIN WARRANTIES, SO SOME OF THE ABOVE LIMITATIONS MAY NOT APPLY TO YOU. 
 </p>
 <p class="style1">12.  Indemnification.  </p>
 <p class="style2">You agree to defend, indemnify and hold harmless  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>, its affiliates and their respective directors, officers, employees and agents from and against all claims, losses, damages and expenses, including attorneys' fees, incurred by us, arising out of your use of the website ( <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>), your use of products and services offered on the website, and/or your breach of this Agreement.  </p>
 
 <p class="style1">13.  Notification of Changes</p>
  <p class="style2">If we decide to change our Policy, we will post these changes on our Homepage or provide other notification of our revised Policy so our users and members are always aware of what information we collect, how we use it, and when we disclose it. </p>
   <p class="style1">14.  General </p>
    <p class="style1">14.1 Governing Law</p>
    
    <p class="style2"> This Site (excluding any linked sites) is controlled by us from our offices within San Pedro, Belize. It can be accessed from all 50 states, as well as from other countries around the world. As each of these places has laws that may differ from those of Belize, by accessing this Site both of us agree that the statutes and laws of Belize, without regard to the conflicts of laws principles thereof and the United Nations Convention on the International Sales of Goods, will apply to all matters relating to the use of this Site and the purchase of products and services available through this Site. We and you each agree and hereby submit to the exclusive personal jurisdiction and venue of the state and federal courts located in San Pedro, Belize, with respect to such matters. </p>
    
    
     <p class="style1">14.2 Legal Compliance </p>
    <p class="style2">You shall comply with all applicable domestic and international laws, statutes, ordinances and regulations regarding Your use of the Site and purchase of products and services on the Site. </p>
    
    
    
     <p class="style1">14.3 Force Majeure</p>
    <p class="style2">Except for the payment of any fees due and payable under this Agreement, neither party's delay in the performance of any duties or obligations under this Agreement will be considered a breach of this Agreement if such delay is caused by a labor dispute, shortage of materials, fire, earthquake, flood, failures in electric power or telecommunications services, or any other event beyond the control of the party. </p>
    
    
     <p class="style1">14.4 Notices </p>
    <p class="style2">Except as explicitly stated otherwise, any notices shall be given by email to  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> Attn: <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span> (in the case of  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>) and to the email address You provide to us during the purchase process (in Your case). Notice shall be deemed given twenty four (24) hours after email is sent, unless  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> is notified that the email address is invalid. Alternatively, we may give You notice by certified mail, postage prepaid and return receipt requested, to the address provided to us during the purchase process. In such case, notice shall be deemed given three (3) days after the date of mailing. </p>
      <p class="style1">14.5 Assignment </p>
    <p class="style2">You shall not assign, transfer or delegate this Agreement or any rights or obligations hereunder. Any assignment, transfer or delegation in contravention of the foregoing provision shall be null and void. You agree that this Agreement may be assigned by  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>, in its sole discretion. </p>
    
      <p class="style1">14.6 No Third-Party Beneficiary </p>
    <p class="style2">You acknowledge and agree that nothing herein, express or implied, is intended to nor shall be construed to confer upon or give to any person, other than the parties, any interests, rights, remedies or other benefits with respect to or in connection with any agreement or provision contained herein or contemplated hereby. </p>
    
     <p class="style1">14.7 Severability Waiver</p>
    <p class="style2">If any provision of this Agreement is held to be invalid or unenforceable, such provision shall be struck and the remaining provisions shall be enforced.  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>&#8217;s failure to act with respect to a breach by You or others does not waive our right to act with respect to subsequent or similar breaches. </p>

    
     <p class="style1">14.8 Construction </p>
    <p class="style2">Headings are for reference purposes only and in no way define, limit, construe or describe the scope or extent of such section. When used in this Agreement, the term "including" means "including without limitation," unless expressly stated to the contrary. </p>
    
    
     <p class="style1">14.9 Survival </p>
    <p class="style2">Sections 6 and 9-12 shall survive expiration or termination of this Agreement. </p>
    
    
     <p class="style1">14.10 Additional Terms </p>
    <p class="style2">The following policies are incorporated into this Agreement by reference and provide additional terms and conditions related to the Services offered by  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span>: <br><br>
    (a) User Agreement <br>
(b) Privacy Policy <br><br>
In addition, when using particular services on the Site, You agree that You are subject to any posted policies or rules applicable to services You use through the Site, which may be posted from time to time. All such posted policies or rules are hereby incorporated by reference into this Agreement. 

</p>
    
    
    
     <p class="style1">14.11 Entire Agreement </p>
    <p class="style2">These terms and conditions constitute the entire agreement and understanding between us and you concerning the subject matter hereof and supersedes all prior agreements and understandings of the parties with respect thereto. These Terms of Conditions and Sale may be modified from time to time by us, but may NOT be altered, supplemented, or amended by the use of any other document(s) submitted by you. Any attempt by you to alter, supplement or amend this document or to enter an order for products or services which are subject to additional or altered terms and conditions shall be null and void, unless otherwise agreed to in a written agreement signed by you and us. To the extent that anything in or associated with this site is in conflict or inconsistent with this Agreement, then this Agreement shall take precedence.  </p>
    
    
    <div id="containerbot">
       <div class="terms_1_1"><img src="https://www.maleperformance-news.com/rln/v1/network/images/disclaimer.png"></div       
    ></div>
    
    
    
    
    </div>
						</section>
				</div> <!--- content -->
			</div> <!--- body-wrapper -->
		</div> <!--- wrapper -->

		<!--- Scripts -->
		<script type="text/javascript" src="https://www.maleperformance-news.com/rln/v1/network/js/jquery-2.0.2.js"></script>

</body>

<!-- Mirrored from www.maleperformance-news.com/rln/v1/network/terms.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Sep 2019 18:54:51 GMT -->
</html>