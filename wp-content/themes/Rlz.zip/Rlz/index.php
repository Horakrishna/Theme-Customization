

<!doctype html>
<html class="no-js" lang="en">
<head>
 <meta charset="utf-8"/>

<title></title>

<meta name="description" content="" />


<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta http-equiv="content-language" content="en-us" />
 
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="HandheldFriendly" content="true"/>
<link rel="icon" href="<?php get_template_directory_uri();?>/images/favicon.ico" type="image/x-icon" />

<script type="text/javascript">
	if (typeof console == 'undefined') {
		var console = {};
		console.log = function() {};
		console.debug = function() {};
		console.info = function() {};
	} 
</script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
 <title>RLZ&trade; Male Enhancement</title>
 <meta name="description" content="">
 <meta name="keywords" content="">

 <style type="text/css">

#popover {

background: #fff ;

display: none;

height: 100%;

left: 0;

position: fixed;

top: 0;

width: 100%;

z-index: 100;

}

#pop-box {

background-color: #fff;

font-size: 24px;

margin: 60px auto;

opacity: 0;

position: relative;

text-align: center;

top: 100px;

transition-delay: 0.75s;

transition-duration: 1s, 1s;

transition-property: opacity, top;

transition-timing-function: ease, ease;

width: 765px;

z-index: 2;

}

.pop-new {

margin: 0 !important;

width: 100% !important;

}

.text_style {

display: block;

text-align: center;

width: 500px;

margin: 30px auto 0;

font-size: 12px;

color: #909193;

line-height: 15px;

    font-family: 'Open Sans', sans-serif;

}

.no_thanks {

display: block;

text-align: center;

width: 500px;

margin: 30px auto 0;

font-size: 12px;

color: #909193;

line-height: 15px;

    font-family: 'Open Sans', sans-serif;

        outline: none;

    text-decoration: underline;

}

</style>




<script type="text/javascript">(function(key,objname,api,reqtype,debug){window["sa_analytics"]=objname;window[objname]=window[objname]|| function(){ (window[objname].tracker=window[objname].tracker||[]).push(arguments)};window[objname].start=(new Date).getTime();window[objname].key=key;window[objname].reqtype=reqtype; window[objname].debug=debug;window[objname].api=api;var script=document.createElement("script");var scripts=document.getElementsByTagName("script")[0];script.async=1; script.src="https://s3.amazonaws.com/saanalytics-scripts-prod/sa_analytics.min.js";scripts.parentNode.insertBefore(script,scripts)}) ("auPfJfgha8XZNgHmEvZ452TbChalLnZ501WPi0F9","saa","https://cw4bdkdff8.execute-api.us-east-1.amazonaws.com/prod/analytics","pixel",false); saa('set','company_crm_id','280'); saa('set_custom',1,'Shipping');  saa("goal","impression");saa('set_custom','2',''); saa('set_custom','3','');saa('set_custom','4','');saa('set_custom','5','');saa('set_custom','6','');saa('set_custom','7','');saa('set_custom','8',''); // must come AFTER setting all other values </script>
<script src="https://api.remarketretarget.com/serve/afrlz/track.js" async></script>   

<?php wp_head();?>    
   </head>
   <body>
<div id="LoadingDiv" style="display:none;"><img src="https://www.maleperformance-news.com/rln/v1/network/images/preloader.gif" class="displayed" alt="" /></div> 
<div id="popover">

<div id="pop-box" style="top: 0px;opacity: 1;" class="pop-new">

<a href="https://www.maleperformance-news.com/rln/v1/network/exit.php"><img src="https://www.maleperformance-news.com/rln/v1/network/images/downsell1.jpg" onClick="javascript:checkoutDownsell();" /></a>

</div>

<p class="text_style">RLZ dual action formula not only gives you an instant surge in sexual

power & performance - but also treats the root cause of sexual dysfunctions, ensuring 

that you are able to satisfy your partner, consistently! Made with herbal extracts and

active botanicals, RLZ is completely safe to use and is free from any

harmful side effects.</p>

<a class="no_thanks" id="noThanks" href="#">No, I don't want to experience sexual power, pleasure & performance</a>

<div id="overlay"></div>

</div>	 
      
        
        
            
    <div class="viewing" id="viewing-lp" style="opacity: 1;">
      <span class="close">x</span>
      <p>13 others are viewing this offer right now - <span class="count-up bl countdown" id="time">10:00</span> <br>
        <a href="index.php">Claim Your Trial Botttle Now!</a>
      </p>
    </div>
 
    <div id="container">
     <div class="tophdr" id="header">
      <div class="contentWrap" style="position:relative;">
       <P class="hdrtxt"><span>WARNING:</span> Due to extremely high media demand, there is limited supply of RLZ in stock as of
        <b><?php echo date('l jS F Y'); ?></b>
      </P>
    </div> 
  </div>
</div>


<div id="section1">
 <div class="sec1inner">
  <div class="contentWrap" style="position:relative;">
   <div class="lft-content">
    <!-- <img src="/xone/us/v2/https://www.maleperformance-news.com/rln/v1/network/images/logo.png" width="239" height="77" alt="" class="s1-logo" /> -->
    <i class="sprite sprite-logo s1-logo"></i>
    <!--  <img src="/xone/us/v2/https://www.maleperformance-news.com/rln/v1/network/images/top-tagline.png" width="565" height="50" alt="" class="s1-tagline" /> -->
    <i class="sprite sprite-top-tagline s1-tagline"></i>
    <p class="s1hding">Medical Strength Male Enhancement</p>
    <p class="s1hding2">Get Maximum
     <br /> <span>Sexual Benefits</span>
   </p>
   <div class="doctor">
     <img src="<?php echo get_template_directory_uri();?>/images/s1no-pres.png" width="504" height="88" alt="" class="s1no-pres" />
   </div>
   <!-- <img src="/xone/us/v2/https://www.maleperformance-news.com/rln/v1/network/images/arrow.png" width="534" height="106" alt="" class="s1-arrow" /> -->
   <i class="sprite sprite-arrow s1-arrow"></i>
   <!-- <img src="/xone/us/v2/https://www.maleperformance-news.com/rln/v1/network/images/product.png" width="288" height="343" alt="" class="s1-prod1" /> -->
   <img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png"  alt="" class="s1-prod1"/>
    <img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png"  alt="" class="s1-prod2" style="left:-81px;"/>
   <img src="<?php echo get_template_directory_uri();?>/images/us-seal.png" width="173" height="173" alt="" class="s1seal" />
   <ul class="s1list">
     <li><span>Bigger & Long-Lasting Erections </span>
      <br />Maximum pleasure & intensified orgasms
    </li>
    <li><span>Surge In Sex Drive & Energy </span>
      <br />Ramps up stamina & staying power
    </li>
    <li><span>Increased Sexual Confidence </span>
      <br />Experience vitality & peak performance
    </li>
  </ul>
  <!--   <img src="/xone/us/v2/https://www.maleperformance-news.com/rln/v1/network/images/as-seen.png" width="467" height="44" alt="" class="as-seen" /> -->
  <i class="sprite2 sprite-as-seen as-seen" width="467" height="44" alt=""></i>
</div>
<div class="rgt-frm">
  <!-- start form -->
  <div class="frm-top"><img src="<?php echo get_template_directory_uri();?>/images/frm-top.png" width="307" height="134" alt="" />
  </div>
  <div class="form-position" id="form-position">
  <form action="submit" method="post" name="order-form" id="order_form" onSubmit="return validate_form();">
          <input type="hidden" name="folder" value="" />
          <input type="hidden" name="campaign_id" value="125" />
          <input type="hidden" name="notes" value="" />
          <input type="hidden" id="submitted" name="submitted" value="1"/>
          <input type="hidden" name="country" id="country" value="US" />
          	
    <div class="fields">
     <div class="label left">First Name:</div>
     <div class="input left">
      <input type="text" id="firstName" name="fields_fname" placeholder="First Name"  value="" data-error-message="Please enter your first name!" />
    </div>
    <div class="spacer clear"></div>
    <div class="label left">Last Name:</div>
    <div class="input left">
      <input type="text" id="lastName" name="fields_lname"  placeholder="Last Name"  value="" data-error-message="Please enter your last name!" />
    </div>
    <div class="spacer clear"></div>
    <div class="label left">Address:</div>
    <div class="input left">
      <input type="text" id="address" name="fields_address1" placeholder="Your Address"  value="" data-error-message="Please enter your address!" />
    </div>
  
    <div class="spacer clear"></div>
    <div class="label left" id="shipToZipLabel">Zip:</div>
    <div class="input left">
      <input type="text" id="postalCode" name="fields_zip" onKeyDown="return onlyNumbers(event,'require')" maxlength="5" placeholder="Zip Code"  value=""   />
      <span id="zip-validate" style="display: none">
      
     </span>
   </div>

    <div class="spacer clear"></div>
    <div class="label left">City:</div>
    <div class="input left">
      <input type="text" id="City" name="fields_city"  placeholder="Your City"  id="fields_city" value="" data-error-message="Please enter your city!" />
    </div>
    <div class="spacer clear"></div>
    <div class="label left" id="shipToStateLabel">State:</div>
    <div class="input left">
      <select name="fields_state" id="states" class="selectbox">
              <option value="">Select State</option>
              <option value="AL">Alabama</option>
              <option value="AK">Alaska</option>
              <option value="AZ">Arizona</option>
              <option value="AR">Arkansas</option>
              <option value="CA">California</option>
              <option value="CO">Colorado</option>
              <option value="CT">Connecticut</option>
              <option value="DE">Delaware</option>
              <option value="DC">District of Columbia</option>
              <option value="FL">Florida</option>
              <option value="GA">Georgia</option>
              <option value="HI">Hawaii</option>
              <option value="ID">Idaho</option>
              <option value="IL">Illinois</option>
              <option value="IN">Indiana</option>
              <option value="IA">Iowa</option>
              <option value="KS">Kansas</option>
              <option value="KY">Kentucky</option>
              <option value="LA">Louisiana</option>
              <option value="ME">Maine</option>
              <option value="MD">Maryland</option>
              <option value="MA">Massachusetts</option>
              <option value="MI">Michigan</option>
              <option value="MN">Minnesota</option>
              <option value="MS">Mississippi</option>
              <option value="MO">Missouri</option>
              <option value="MT">Montana</option>
              <option value="NE">Nebraska</option>
              <option value="NV">Nevada</option>
              <option value="NH">New Hampshire</option>
              <option value="NJ">New Jersey</option>
              <option value="NM">New Mexico</option>
              <option value="NY">New York</option>
              <option value="NC">North Carolina</option>
              <option value="ND">North Dakota</option>
              <option value="OH">Ohio</option>
              <option value="OK">Oklahoma</option>
              <option value="OR">Oregon</option>
              <option value="PA">Pennsylvania</option>
              <option value="PR">Puerto Rico</option>
              <option value="RI">Rhode Island</option>
              <option value="SC">South Carolina</option>
              <option value="SD">South Dakota</option>
              <option value="TN">Tennessee</option>
              <option value="TX">Texas</option>
              <option value="UT">Utah</option>
              <option value="VT">Vermont</option>
              <option value="VI">Virgin Islands of the U.S.</option>
              <option value="VA">Virginia</option>
              <option value="WA">Washington</option>
              <option value="WV">West Virginia</option>
              <option value="WI">Wisconsin</option>
              <option value="WY">Wyoming</option>
            </select>   
    </div>

   <div class="spacer clear"></div>
   <div class="label left hidden">Country:</div>
   <div class="input left hidden">
    <select name="shippingCountry"  data-selected="US" data-error-message="Please select your country!">
     <option value="US"></option>
   </select>
 </div>
 <div class="spacer clear hidden"></div>
 <div class="label left">Phone:</div>
 <div class="input left">
  <input type="text" onKeyDown="return onlyNumbers(event,'require')" id="phone" name="fields_phone" placeholder="Phone"   maxlength="10"  placeholder="Phone"   />
</div>
<div class="spacer clear"></div>
<div class="label left">Email:</div>
<div class="input left">
  <input type="text" id="email" name="fields_email" placeholder="Email Address"  value=""
   />
  <span id="mxcheck-placeholder" style="display:none;">
   
 </span>
 <span id="mxcheck-message" style="display:none;"></span>
</div>
<div class="spacer clear"></div>
<div class="clear"></div>
<!-- <input type="submit" value="submit"> -->

<div class="frm-btm">
  <img src="<?php echo get_template_directory_uri();?>/images/lock.png" width="199" height="10" alt="" class="lock" />
  <input type="image" src="<?php echo get_template_directory_uri();?>/images/submit-btn.png" alt="" class="submit pulse" />
  <img src="<?php echo get_template_directory_uri();?>/images/frm-btm.png" width="164" height="39" alt="" class="security" />
</div>
<div class="clear"></div>
</div>
</form>
</div>
<div class="clearall"></div>
<!-- end form -->
</div>
</div>
</div>
</div>
<div id="section2">
  <div class="sec2inner">
    <div class="contentWrap" style="position:relative;">
     <p class="sec2hding"><span>The Sexual Health Divide </span>
      <br />Are You Suffering From The Following Symptoms
    </p>
    <p class="s2txt">Leading surveys on sexual health and satisfaction levels among
      <br />American men have revealed the following:
    </p>
    <div class="box-area">
      <div class="s2box1">
       <center>
        <i class="sprite sprite-s2one"></i>
      </center>
      <p class="s2box-txt">Say sexual health impacts on overall life satisfaction</p>
    </div>
    <div class="s2box2">
     <center>
      <i class="sprite sprite-s2two"></i>
     
    </center>
    <p class="s2box-txt">Of men suffer from Small Penis
      <br />Syndrome
    </p>
  </div>
  <div class="s2box3">
    <center>
      <i class="sprite sprite-s2three"></i>
    </center>
    <p class="s2box-txt">Believe
      <br />embarrassment is a major sexual barrier
    </p>
  </div>
  <div class="s2box4">
    <center>
      <i class="sprite sprite-s2four"></i>
    </center>
    <p class="s2box-txt">Avoid sex altogether because of lack of sexual confidence</p>
  </div>
</div>
</div>
</div>
</div>
<div id="section3">
  <div class="sec3inner">
    <div class="contentWrap" style="position:relative;">
     <img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png" width="313" height="374" alt="" class="s3-prod1" />
     <img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png" width="375" height="449" alt="" class="s3-prod2" />
     <img src="<?php echo get_template_directory_uri();?>/images/us-seal.png" width="120" height="120" alt="" class="satisfaction-seal" />
     <!--  <i class="sprite2 sprite-us-seal satisfaction-seal"  width="120" height="120" alt="" ></i> -->
     <p class="s3hding"><span>Introducing RLZ</span>
      <br /> Male Enhancement System
    </p>
    <p class="sec3txt"><b>Made with a blend of clinical strength ingredients, <span>RLZ is a male enhancement system</span> that has
      been formulated to restore your sexual youth and performance and help you experience an intense, blissful & powerful
      sex life. </b>
      <br />
      <br />
      <strong>RLZ</strong> dual action formula not only gives you an instant surge in sexual power & performance - but also treats the root cause of sexual dysfunctions, ensuring that you are able to satisfy your partner, consistently! Made with herbal extracts and active botanicals, <b>RLZ</b> is completely safe to use and is free from any harmful side effects.
    </p>
    <p class="sec3txt2">Triple IntenSity
      <br /><span>Male Enhancement </span>
      <br />For maximum Results
    </p>
    <p class="sec3txt3">The pro-sexual nutrient matrix in RLZ helps boost the 3S's of Sex - Size, Stamina & Satisfaction, helping you peak perform and pleasure your partner just like you did in your 20's!</p>
    <p class="sec3txt4"><b>RLZ</b> is proudly made in the United States of America at a certified manufacturing facility to meet statutory industry standards. Every purchase is backed by a Satisfaction Guarantee, so that you can enjoy the benefits with confidence. </p>
    <div class="btn-strip">
      <p class="btn-txt"><span>ORDER YOUR RLZ TODAY!</span>
       <br /> Experience Sexual Power, Pleasure & Performance
     </p>
     <a href="javascript:bookmarkscroll.scrollTo('header')">
     
       <i class="sprite2 sprite-submit-btn sec3btn pulse" width="275" height="70" alt="" ></i>
     </a>
   </div>
 </div>
</div>
</div>
<div id="section4">
  <div class="contentWrap">
    <p class="s4hding"><span>THE SCIENCE BEHIND </span>
     <br />BETTER, LONGER & MORE INTENSE SEX!
   </p>
   
   <i class="sprite2 sprite-s4seal s4seal" width="156" height="156" alt="" ></i>
   <p class="s4txt"> <span>The blood flow to the penis is responsible for erections while the <br />holding capacity of the penis
     chambers is what influences sexual stamina <br />and staying power. <b>RLZ</b> helps boost both to help you and your partner
     <br />partner enjoy intense orgasms and complete satisfaction.</span>
     <br />
     <br />
     <strong>RLZ</strong> pro-sexual nutrient blend is quickly absorbed into the bloodstream to stimulate Nitric Oxide production - this in turn boosts the flow of blood to the penile chambers helping you enjoy harder and stronger erections. On the other hand it also expands the penis chambers allowing it to hold more blood in order to drastically increase sexual stamina, strength and staying power.
   </p>
   <p class="s4txt2"><b>RLZ</b> utilizes a breakthrough rapid absorption and extended release technology. Rapid absorption of the ingredients into the bloodstream aid in delivering instant surge of sexual power while the extended release technology delivers sustained results that help you enjoy on command erections and stamina to last all night long. </p>
  
   <i class="sprite2 sprite-s4img s4img" width="325" height="369" alt="" ></i>
   <p class="s4txt3"><span>RLZ</span> works by triggering the two mechanisms known
     <br />to increase penis size, function and performance. These are:
   </p>
   <p class="s4txt4">An increase in "free" testosterone and</p>
   <p class="s4txt5">Nitric Oxide production to the penis.</p>
   <p class="s4txt6"><span>RLZ is the only product that does both.</span> RLZ contains the most potent
     <br /> nitric oxide stimulators which maximize the delivery of the active ingredients
     <br /> to your penile tissue giving you firmer, longer erections.
   </p>
   <div class="s4btn-strip">
     <p class="btn-txt"><span>ORDER YOUR RLZ TODAY!</span>
      <br /> Experience Sexual Power, Pleasure & Performance
    </p>
    <a href="javascript:bookmarkscroll.scrollTo('header')">
     
      <i class="sprite2 sprite-submit-btn sec3btn pulse" width="275" height="70" alt="" ></i>
    </a>
  </div>
</div>
</div>
<div id="section5">
  <div class="sec5inner">
    <div class="contentWrap">
     <p class="s5hding"><span>The Benefits of RLZ</span>
      <br />ADVANCED MALE ENHANCEMENT!
    </p>
    <p class="sec5txt"><span>RLZ Male Enhancement System</span> offers multiple sexual health benefits to help you
      <br />enjoy hard erections, increased stamina and peak performance.
    </p>
    <div class="s5benefits">
      <div class="s5box1">
       <p class="bnft-txt">IMPROVED LIBIDO & SEX DRIVE</p>
       <p class="bnft-txt2">Get ready to
        <br />experience a torrent of desire & passion with <b>RLZ</b>, which replenishes sexual energy stores across the body like never before.
      </p>
    </div>
    <div class="s5box2">
     <p class="bnft-txt">INCREASED STAYING
      <BR />POWER
    </p>
    <p class="bnft-txt2">Bid goodbye to pre-
      <br />mature ejaculations! <b>RLZ</b> floods your penile chambers with a gush of blood letting you last 5X more than usual and helping you last all night long!
    </p>
  </div>
  <div class="s5box5">
    <p class="bnft-txt">BIGGER, HARDER & LONGER ERECTIONS</p>
    <p class="bnft-txt2"><b>RLZ</b> lets you achieve rock hard erections on command helping you and your partner enjoy insane sexual sessions, whenever you desire.</p>
  </div>
  <div class="s5box4">
    <p class="bnft-txt">IMPROVED SEXUAL CONFIDENCE</p>
    <p class="bnft-txt2">Equipped with youthful sexual powers & energy, you are sure to experience sexual confidence like never before, gives you greater success with the most desirable women!</p>
  </div>
  <div class="s5box3">
    <p class="bnft-txt">INCREASED
      <br />PENIS
      <BR />SIZE
    </p>
    <p class="bnft-txt2">Increase in penile chamber capacity and regular boost in blood flow may help add those inches to your penis size, both length & girth wise.</p>
  </div>
</div>
<img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png"  width="268" height="320" alt="" class="s5-prod1" />
<img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png" width="268" height="320" alt="" class="s5-prod2" />
<img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png"  height="385" class="s5-prod3" />
<img src="<?php echo get_template_directory_uri();?>/images/satisfaction-seal.png" width="127" height="108" alt="" class="s5img" />
<!-- <i class="sprite2 sprite-satisfaction-seal s5img" width="127" height="108" alt="" ></i> -->
<!--  <img src="/xone/us/v2/https://www.maleperformance-news.com/rln/v1/network/images/s5img.png" width="79" height="118" alt="" class="s5img2" /> -->
<i class="sprite2 sprite-s5img s5img2" width="79" height="118" alt="" ></i>
<p class="s5lft-txt"><span>Our product backed with a</span>
  <br />100% Satisfaction
  <br />Guarantee!
</p>
<p class="s5rgt-txt"><span>THE NUMBER ONE</span>
  <br />MALE ENHANCEMENT
  <br /><b> PILL IN THE US</b>
</p>
<div class="clearall"></div>
<div class="s5btn-strip">
  <p class="btn-txt"><span>ORDER YOUR RLZ TODAY!</span>
   <br /> Experience Sexual Power, Pleasure & Performance
 </p>
 <a href="javascript:bookmarkscroll.scrollTo('header')">
 <?php echo get_template_directory_uri();?>
   <i class="sprite2 sprite-submit-btn sec3btn pulse" width="275" height="70" alt="" ></i>
 </a>
</div>
</div>
</div>
</div>
<div id="section6">
  <div class="sec6inner">
    <div class="contentWrap" style="position:relative;">
     <p class="s6hding"><span>Powerful Ingredients</span>
      <br />For Bigger Results
    </p>

    
    <i class="sprite2 sprite-natural-seal natural-seal" width="160" height="222" alt=""></i>
    <div class="sec6lft">
      <p class="s6ingrnts1">L-Arginine</p>
      <p class="s6txt">Stimulates nitric oxide production to boost blood circulation to the penis helping achieve biggers and stronger erections. </p>
      <p class="s6ingrnts2">Ginko Biloba Extarct</p>
      <p class="s6txt" style="padding-top:84px;">An aphrodisiac, it helps boost male sexual drive and libido. It also supports healthy testosterone levels. </p>
    </div>
    <div class="sec6rgt">
      <p class="s6ingrnts3">Muira Puama Extract</p>
      <p class="s6txt2">Called the "Viagra of Amazon", this herbal extract
       <br />replenishes sexual energy stores for improved
       <br />strength and stamina.
     </p>
     <div class="clearall"></div>
     <div class="lftingrnts">
       <p class="s6ingrnts4">Asian Red
        <br /> Ginger Extracts
      </p>
      <p class="s6txt3">Positively influences mood patterns to reduce stress and promote relaxation, enabling men to perform at their peak. </p>
    </div>
    <div class="rgtingrnts">
     <p class="s6ingrnts5">Saw Palmetto
      <br />Berry
    </p>
    <p class="s6txt3">Helps increase staying power ensuring you and your partner enjoy longer sessions with intense orgasms. </p>
  </div>
  <div class="clearall"></div>
  <p class="s6ingrnts6">Horny Goat Weed
    <br />Extract
  </p>
  <p class="s6txt2">Works synergistically with the other pro-sexual nutrients to boost blood flow to the penile chambers for improved erections. It also helps expand the chambers to increase blood holding capacity and in-turn staying power.</p>
</div>
<div class="clearall"></div>
<p class="s6btm-txt"><span>Bioperine&trade;</span>
  <br />Helps support the formula's quick absorption technology. This allows the key herbal ingredients that support male enhancement to be absorbed quickly into the blood stream, triggering an instant boost in sexual energy, stamina and erections.
</p>
<div class="s6btn-strip">
  <p class="btn-txt"><span>ORDER YOUR RLZ TODAY!</span>
   <br /> Experience Sexual Power, Pleasure & Performance
 </p>
 <a href="javascript:bookmarkscroll.scrollTo('header')">
  
   <i class="sprite2 sprite-submit-btn sec3btn pulse" width="275" height="70" alt="" ></i>
 </a>
</div>
</div>
</div>
</div>
<div id="section7">
  <div class="sec7inner">
    <div class="contentWrap" style="position:relative">
     <p class="s7hding"><span>REAL MEN, REAL RESULTS</span>
              <br />Success Stories From Our Patrons
            </p>
            <p class="s7txt"><span>RLZ has helped hundreds of men across all ages</span> beat sexual dysfunction
              <br />and enjoy a fuller and satisfied sex life.
            </p>
            <div class="slider">
              <div class="slide1">
               <div class="lft-box">
               
                <i class="sprite2 sprite-sliderimg sliderimg" width="155" height="158" alt="" ></i>
               
                <i class="sprite2 sprite-star star"  width="101" height="18" alt="" ></i>
                <p class="sldr-tstimnl">"<b>RLZ</b> is truly the best male enhancement system in the market! Unlike other products that have synthetics, <b>RLZ</b> is made with herbal extracts and botanicals which have been clinically proven to boost virility. I did a thorough research before picking up the product and the results have been truly phenomenal. Highly recommended. "</p>
                <p class="tstmnl-name"><span>- Carlos Velez, 43 </span>
                </p>
              </div>
              <div class="rgt-box">
                <p class="clearall"></p>
                
                <i class="sprite2 sprite-sliderimg2 sliderimg" width="155" height="158" alt="" ></i>
                
                <i class="sprite2 sprite-star star"  width="101" height="18" alt="" ></i>
                <p class="sldr-tstimnl">"The age related ED issues were very frustrating and no pill seemed to work! When my friend recommended <b>RLZ</b>, I decided I will give it a try and I am glad I did! It has helped me boost my sexual stamina, size and confidence. And guess who is a bigger fan of <b>RLZ</b> than me, my wife! "</p>
                <p class="tstmnl-name2"><span>- Rob Greco, 54</span>
                </p>
              </div>
            </div>
                <div class="slide2">
                 <div class="lft-box">
                  <img src="<?php echo get_template_directory_uri();?>/images/sliderimg3.png" width="155" height="158" alt="" class="sliderimg" />
                     <i class="sprite2 sprite-star star"  width="101" height="18" alt="" ></i>
                     <p class="sldr-tstimnl">"Its great to know that my favorite male enhancement supplement is now available in the market without a prescription! I have been using <b>RLZ</b> for a few months now and the results have been truly "huge"! I am able to enjoy harder erections, increased sexual drive and stamina, which lets me enjoy love making just like I used to when I was in my 30s! "</p>
                     <p class="tstmnl-name" style="padding:25px 0 0 21px;"><span>- Vincent Harper, 49</span>
                     </p>
                   </div>
                   <div class="rgt-box">
                    <p class="clearall"></p>
                    <img src="<?php echo get_template_directory_uri();?>/images/sliderimg4.png" width="155" height="158" alt="" class="sliderimg" />

                    <i class="sprite2 sprite-star star"  width="101" height="18" alt="" ></i>
                    <p class="sldr-tstimnl">"Age related decline in sexual health along with onset of mild ED had left me pretty shattered. I came across <b>RLZ</b> on a very reputed blog for male health and decided to give it a try. It has been the best decision I ever made. My sex drive has really taken off, my erections are back to their firm and the increase in sexual stamina is just amazing! "</p>
                    <p class="tstmnl-name2" style="padding:25px 0 0 21px;"><span>- Sean Carter, 56</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="section8">
         <div class="contentWrap" style="position:relative">
          <img src="<?php echo get_template_directory_uri();?>/images/logo.png" width="239" height="77" alt="" class="s8-logo" />
          <img src="<?php echo get_template_directory_uri();?>/images/s1no-pres.png" width="504" height="88" alt="" class="s8no-pres" />
          <p class="s8hding">Medical Strength Male Enhancement</p>
          <p class="s8hding2">Get Maximum
           <br /> <span>Sexual Benefits</span>
         </p>

         <i class="sprite2 sprite-us-seal s8seal2"  width="173" height="173" alt="" ></i>
         <img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png" width="286" height="341" alt="" class="s8-prod1" />
         <img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png" width="286" height="341" alt="" class="s8-prod2" />
         <img src="<?php echo get_template_directory_uri();?>/images/MALE PERFORMANCE XL Bottle.png" width="411" height="493" alt="" class="s8-prod3" />
         <ul class="s8list">
           <li><span>Bigger & Long-Lasting Erections </span>
            <br />Maximum pleasure & intensified orgasms
          </li>
          <li><span>Surge In Sex Drive & Energy </span>
            <br />Ramps up stamina & staying power
          </li>
          <li><span>Increased Sexual Confidence </span>
            <br />Experience vitality & peak performance
          </li>
        </ul>
        <a href="javascript:bookmarkscroll.scrollTo('header')">
         <!--  <img src="/xone/us/v2/https://www.maleperformance-news.com/rln/v1/network/images/submit-btn.png" width="275" height="70" alt="" class="sec8btn pulse" />  -->
         <i class="sprite2 sprite-submit-btn sec8btn pulse" width="275" height="70" alt="" ></i>
       </a>
     </div>
   </div>
   
   <div class="footer">
     <div class="wrap">
      <ul>
       
	<li><a class="footerlink" onClick="newWindow('<?php echo get_template_directory_uri();?>/terms.php','','1100','600','resizable,scrollbars')">Terms &amp; Conditions</a>
       </li>
       <li>|</li>
       <li><a class="footerlink" onClick="newWindow('<?php echo get_template_directory_uri();?>/privacy.php','','1100','600','resizable,scrollbars')">Privacy Policy</a>
       </li>
       <li>|</li>
       <li><a class="footerlink" onClick="newWindow('<?php echo get_template_directory_uri();?>/contact.php','','1100','600','resizable,scrollbars')">Contact</a>
       </li>
       <li>|</li>
       <li><a class="footerlink" onClick="newWindow('<?php echo get_template_directory_uri();?>/ingredients.php','','1100','600','resizable,scrollbars')">Ingredients</a>
       </li>
     </ul>
      
      
      
      
      
      <div class="inner-wrap">
   
	<img src="<?php echo get_template_directory_uri();?>/images/disclaimer.png"><br>
    
    
    
    
     <div align="center" class="style12white_1"  style="">Representations regarding the efficacy and safety of RLZ have not been scientifically substantiated or evaluated by the Food and Drug Administration. <a href="javascript:void(0);"  onClick="newWindow('http://www.jurology.com/article/S0022-5347(05)64298-X/abstract','','1100','600','resizable,scrollbars')" id="rd5">Click here</a>, <a href="javascript:void(0);"  onClick="newWindow('http://www.ncbi.nlm.nih.gov/pmc/articles/PMC3861174/','','1100','600','resizable,scrollbars')"  id="rd5">Click here</a> and <a href="javascript:void(0);"  onClick="newWindow('http://jap.physiology.org/content/jap/early/2010/08/19/japplphysiol.00503.2010.full.pdf','','1100','600','resizable,scrollbars')"  id="rd5">Click here</a> to find evidence of a test, analysis, research, or study describing the benefits, performance or efficacy of nitric oxide based on the expertise of relevant professionals.</div>
       <div align="center" id="footer_1">
      RLZ 2019</div>
    </div>

   </div>
 </div>
 

<script type="text/javascript"> (function(key,objname,api,reqtype,debug){window["sa_analytics"]=objname;window[objname]=window[objname]|| function(){ (window[objname].tracker=window[objname].tracker||[]).push(arguments)};window[objname].start=(new Date).ge tTime();window[objname].key=key;window[objname].reqtype=reqtype; window[objname].debug=debug;window[objname].api=api;var script=document.createElement("script");var scripts=document.getElementsByTagName("script")[0];script.async=1; script.src="https://s3.amazonaws.com/saanalytics-scripts-prod/sa_analytics.min.js";scripts.parentNode.ins ertBefore(script,scripts)}) ("auPfJfgha8XZNgHmEvZ452TbChalLnZ501WPi0F9","saa","https://cw4bdkdff8.execute-api.us-east-1.amazonaws.com/prod/analytics","pixel",false); saa('set','company_crm_id','280'); saa('set_custom',1,'Sandy');  saa("goal","conversion"); // must come AFTER setting all other values </script>
<script>
$(document).ready(function(){
$("form input, select").blur(function(){
validate_single_index(this.id);
});
});
$(document).ready(function() {
modalOnClick();
});
</script>	
 
<script type="text/javascript">
//window.onbeforeunload = grayOut;
function grayOut(){
var ldiv = document.getElementById('LoadingDiv');
ldiv.style.display='block';
}
</script>


<script type='text/javascript'>

 function newWindow(url, title, w, h) {

    // Fixes dual-screen position                         Most browsers      Firefox

    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;

    var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;



    var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;

    var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;



    var left = ((width / 2) - (w / 2)) + dualScreenLeft;

    var top = ((height / 2) - (h / 2)) + dualScreenTop;

    var newWindow = window.open(url, title, 'scrollbars=yes, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);



    // Puts focus on the newWindow

    if (window.focus) {

        newWindow.focus();

    }

}

</script>

<br /><br /><br /><div class="app-benchmark"><small>page loaded in: 0.05 seconds | memory used: 3.1 mb</small></div>   

<span style="display: inline; padding: 0px; margin: 0px; border: 0px; position: fixed; bottom: 0px; top: auto; right: auto; left: 0px; z-index: 10001; background-color: transparent; height: auto; width: auto;" class="safe-buy"><img src="https://www.maleperformance-news.com/rln/v1/network/images/safepurchase.png" border="0" style="vertical-align: bottom;"></span>



<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.26/angular.min.js"></script>


<script type="text/javascript">
$('#noThanks').click(function () {
$('#popover').hide();
});
function skipDownSell(){
$('#popover').fadeOut();
}
var leave = true;
$('[name="sprotect"]').click(function() {
if ($(this).is(':checked')) {
$('input[name="disable_split_order"]').val('0');
} else {
$('input[name="disable_split_order"]').val('1');
}
});
</script>

<script>

function toggleCardType(cardType) {

var cardLogos = $('ul.all-card-types li');



if (cardType && cardType.length > 0) {

cardLogos.each(function () {

if ($(this).hasClass(cardType)) {

$(this).removeClass('off').show();

} else {

$(this).addClass('off').hide();

}

});

} else {

cardLogos.removeClass('off').show();

}

}



function checkoutDownsell() {

$('input[name=shippingId]').val(4);

$('input[name=prepaid_shippingId]').val(4);

$('input[name=productId]').val(1122);

$('input[name=dynamic_product_price_1122]').val(0);



$('#popover').fadeOut();

$('.rgtrow').html('$'+'1.95');

}



function startTimer(duration, display) {

var timer = duration, minutes, seconds;

setInterval(function () {

minutes = parseInt(timer / 60, 10)

seconds = parseInt(timer % 60, 10);

minutes = minutes < 10 ? "0" + minutes : minutes;

seconds = seconds < 10 ? "0" + seconds : seconds;

display.text(minutes + ":" + seconds);

if (--timer < 0) {

timer = duration;

}

}, 1000);
}
jQuery(function ($) {

var fiveMinutes = 60 * 5,

display = $('#stopwatch');

startTimer(fiveMinutes, display);

});

</script>
<script>
function init() {
setTimeout(function(){window.scrollTo(0,1)},0);
}

window.history.pushState('back.html', 'back', 'back.html');
window.history.pushState('index.php', 'Index', 'index.php');
window.addEventListener("popstate", function(e) {
if(document.URL.indexOf("back.html") >= 0){
document.location.href = document.location;
}

});
</script>
<?php wp_footer(); ?>
</body>
</html>
