<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from www.maleperformance-news.com/rln/v1/network/privacy.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Sep 2019 18:54:51 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=iso-8859-1" /><!-- /Added by HTTrack -->
<head>
	<meta name="robots" content="noindex,nofollow,noarchive,nosnippet,noydir,noodp" />
	<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<meta name="googlebot" content="NOINDEX, NOFOLLOW">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
<title>Privacy Policy</title>
	<link rel="stylesheet" type="text/css" href="https://www.maleperformance-news.com/rln/v1/network/css/pre-defined.css"> <!--- CSS Reset and Pre Defined -->
	<link rel="stylesheet" type="text/css" href="https://www.maleperformance-news.com/rln/v1/network/css/cart.css"> <!--- Main Custom CSS -->
	<!--- core CSS and favicon-->
<style type="text/css">
<!--
#red16bold {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    font-size: 16px;
    color: #f00;
    font-weight: bold;
}
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	font-weight: bold;
	color: #F00;
}
.style3 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	font-weight: bold;
	color: #F00;
}
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
.terms_1_1{
	text-align: center;
	padding-top: 10px;
}
-->
</style>

</head><!--/head-->

<body>

		<div id="site-wrap">

		  <div id="body-wrapper">
				<div id="content">

						<section id="alpha-header">
							
						</section>

						<section id="cart-content" class="third-step">
							<div class="inner-wrap py clearfix">
    <div id="red16bold">PRIVACY POLICY</div>
  <hr />
              <p class="style2">Policy last updated on 09/27/2019.<br><br>
This is the Privacy Policy for  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> ("Site"), which is owned and operated by  <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=Male%20Enhancement%20Formula&amp;c=pr" /></span> ("Company" or "we" or "us")<br><br>
The following policy explains how we collect and use personal information in detail.  If you have any concerns about this policy, please feel free to contact us at <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span>
</p>
              <p><span class="style1">Your Acceptance of this Privacy Policy</span></p>
              <p class="style2">By registering and using this Site, including, without limitation, signing up for offers and/or continuing to receive information from Company, you signify your acceptance of this Policy, and you expressly consent to our use and disclosure of your personal information in accordance with this Privacy Policy. This Privacy Policy is subject to the <a href="https://www.maleperformance-news.com/rln/v1/network/terms.php"  class="style2" style="text-decoration:none;" target=_blank">Terms</a> of Use posted on the Site.  If you do not agree to the terms of this Policy, in whole or part, you should not use this Site, and should instantly cancel your registration (if you have signed up) by following the directions in the section "Opting-Out of Further Communications:"</p>
              <p class="style1">Registration; Collection and Use of Information:</p>
                <p class="style2">Anyone completing and submitting any of the forms or sections on the Site is considered a "registrant." When you register with Company, you automatically allow registration with all the other sites in the Company&#8217;s network (collectively, the "Network Sites").  Accordingly, we may share registrant PII with the Network Sites.<br><br>
Company only gathers personal identifiable information ("PII") that is volunteered during the registration process or in response to specific information requests.  Examples of PII that may be requested consist of name, address, email address, and telephone number.  We also collect credit card or other payment account information in connection with any purchase you make on or through the Site.  The decision to provide PII is optional on your part; however, if you decide not to register or provide such information, you may not be able to use certain features of the Site or other services on or through the Site.<br><br>  
We also may automatically collect non-personal information that does not identify an individual user, such as IP (internet protocol) address, ISP (internet service provider), the Web browser used to visit the Site, the time the Site is visited, which Web pages were visited on the Site, a unique mobile device identifier (in connection with the use of the Sites or related services from mobile devices) and other anonymous Site usage data.<br><br>
We may also connect personal information and non-personal information from users via "cookies" (small text files placed by us on user computers), single-pixel GIF image files (also called "Web beacons"), Web server log analysis and other similar technologies. Such information may be used to track usage trends and enhance the user experience, and may be shared with third parties.<br><br>
We use your PII and non-personal information for internal purposes, such as to provide you with the Site and services, to notify you of new products or services, and to otherwise communicate with you.<br><br> 
To the extent third parties may place advertising on the Site, such third parties may utilize cookies or other tracking technologies. We are not responsible for information collected by third parties in this manner, nor for the collection or use of information by other sites to which the Site is linked.<br><br>
By providing PII and other information to this Site, registrant fully understands and expressly consents to the collection and use of such information and the transfer of such information to Network Sites and other parties, in accordance with the terms of this Policy.
</span></p>
              <p class="style1">Sharing Information; Your Consent to Sharing</p>
                <p class="style2">Company reserves the right to use registrant PII: (1) for the specific purpose for which such information was provided (including matching registrants with a payday loan company or companies); Please be aware that in the process of matching registrants with a lender or service provider we provide registrant PII to those companies. In addition, in order to determine whether your registration information meets their lending criteria they may access your credit report or credit information through a credit bureau or similar service, which may result in one or more inquiries on your credit report; (2) as disclosed at the time such information is provided ; and (3) as disclosed in this Policy.<br><br>   
 We may rent, sell, and share your PII and non-personal information with the Network Sites and other third parties for the purposes of direct mail, email marketing, mobile marketing, and telemarketing.  We are expressly not responsible for, and have no liability for, the services or representations you may receive from those parties.<br><br>
By clicking "Submit" and providing personal information on or through the Site, you agree:<br><br>
&#8226;	all information you have provided is true and correct to the best of your knowledge;<br><br>
&#8226;	you are establishing a business relationship with Company, the Network Sites, and its other marketing partners; and<br><br>
&#8226;	you are requesting and expressly consenting to be contacted via telephone (whether wireless or wired, including calls using an automated dialing system), email, and/or mail by us, the Network Sites, and other third parties, with offers of other products and services, and for any other legitimate purpose, regardless of whether your telephone number is on any Do Not Call list(s)
We may work with third-party marketing and advertising companies ("Ad Networks").  These companies may collect and use information about your use of the Site or services in order to provide advertisements about goods and services that may be of interest to you.  Advertisements may be shown via the Site, the services, or third-party sites.  These companies may place or recognize a unique cookie on your computer or use other technologies such as Web beacons.  Our Privacy Policy does not cover any use of information that an Ad Network may collect from you.  It also does not cover any information that you may choose to provide to an Ad Network or to an advertiser whose goods or services are advertised through the Site.  For more information about ad cookies, and to "opt-out" of the collection of information by some companies that allow you to do so, please email.<br><br>
If you do not concur that Company may share your PII and non-personal information with such parties, you should not register on and use the Site and, if you are already registered, you must immediately cancel your account, by following the instructions in "Opting-Out of Further Communications".<br><br> 
Company attempts to advise others who receive registrant PII to support this Privacy Policy.  Please be aware, however, that we have no control over such other party's information use practices and we are not liable for any failure of such party to adhere to this Policy or otherwise to violate your privacy.<br><br>
Finally, Company may disclose registrant PII in order to: (1) comply with applicable laws; (2) respond to governmental inquiries; (3) comply with valid legal process; and (4) protect the rights or property of Company, the Network Sites or other registrants of this Site.
</p>
              <p  class="style1">Mobile Services</p>
                <p class="style2">Any information we obtain from you in connection with any mobile service, including SMS services, may include your name, address, mobile phone number, your mobile service provider's name, and the date, time, and content of your messages. In addition to any fee we may charge, your mobile service provider's standard messaging rates apply to our confirmation and all subsequent SMS correspondence. All charges are billed by and payable to your mobile service provider. We will not be liable for any delays in the receipt of any SMS messages, as delivery is subject to effective transmission from your network operator. SMS message services are provided on an AS IS basis.  You may opt out of mobile services via email to <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span> or by sending "STOP", "END", "QUIT" to the SMS text message you have received. However, such opting out will not apply to any communications from our other website offerings you have registered for or from the Network Sites or other third parties to whom we may have already provided your information.</p>
              <p class="style1">Opting-Out of Further Communications:</p>
              <p class="style2">Site registrants may opt-out of receiving further communications from Company.  Registrants may, at any time, choose not to receive promotional emails from Company, the Network Sites, or other parties by (1) following the "unsubscribe" instructions in any such e-mail received by registrant, or (2) writing to <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span>.<br><br>
Note that unsubscribing from one email list does not automatically unsubscribe you from any other email list that you may be on.  Please read the email carefully to find out which list you are unsubscribing from.<br><br>

Registrants also may opt out of receiving telephone calls from Company, Network Sites or others with whom we have shared your information by requesting to be placed on its company-specific do-not-call list.  
</p>
              
			
			
              <p class="style1">Transfer In Certain Circumstances:</p>
                <p class="style2">In its sole discretion, Company may transfer, sell or assign information collected on and through this Site, including without limitation, PII and other registrant-provided information, to one or more third parties, as a result of the sale, merger, consolidation, change in control, transfer of substantial assets, reorganization or liquidation of Company and/or Network Sites.</p>
                  <p class="style1">Security, Fraud, and Abuse:</p>
                <p class="style2">This site has security measures in place to protect the loss, misuse, and alteration of the information under our control.  Company regularly reviews these measures to better protect you. However, we do not and cannot guarantee the security or integrity of the information, and we have no liability for breaches of said security or integrity or third-party interception in transit. Please be advised that any transmission of data at or through the Site is at your own risk.   
			</p>
              <p class="style1">Must Be 18 Years or Older:</p>
                <p class="style2">Neither Company nor the Network Sites are intended for, or directed to, children under the age of 18. If we learn that a person who registers on the Site is under the age of 18, we will promptly delete that individual's registration. </p>
              <p class="style1">Links to Other Sites:</p>
                <p class="style2">The Site may contain links to other sites, or allow others to send you such links.  A link to a third party&#8217;s site does not mean we endorse it or are affiliated with it.  We exercise no control over third-party sites and  are not responsible for the privacy practices or content of those sites.  Your access to such third-party sites or content is at your own risk.  You should always read the privacy policy of a third-party site before providing any information to the site.</p>
              <p class="style1">Change in Policy:</p>
                <p class="style2">Company may, from time to time, amend this Policy, in whole or part, in its sole discretion. Depending on the nature of the change, we will either announce the change (1) on the privacy policy page of the site, or (2) provide such notice via e-mail to registrants. Those changes will go into effect on the revision date shown in the revised Privacy Policy.  Your continued use of our Site and services constitutes your consent to be bound by the revised Privacy Policy.  If you do not agree with the terms of this Policy, as it may be amended from time to time, in whole or part, you must terminate your registration by unsubscribing at <span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span> and cease all further use of the Site.</p>
              
              <p class="style1">Contacting Us</p>
                <p class="style2">If you have any questions or concerns about this Privacy Policy or our privacy practices, you may write to us at:<br><br>
<span style="position:relative;top:6px;"><img src="https://www.maleperformance-news.com/rln/v1/network/createimage.php?text=support@maleperformance-news.com&amp;c=em" /></span><br><br>
Please provide complete information to facilitate your request, as well as your complete contact information.
</p>    <div id="containerbot">
       <div class="terms_1_1"><img src="https://www.maleperformance-news.com/rln/v1/network/images/disclaimer.png"></div       
    ></div>
    
    
    
    
    </div>
						</section>
				</div> <!--- content -->
			</div> <!--- body-wrapper -->
		</div> <!--- wrapper -->

		<!--- Scripts -->
		<script type="text/javascript" src="https://www.maleperformance-news.com/rln/v1/network/js/jquery-2.0.2.js"></script>

</body>

<!-- Mirrored from www.maleperformance-news.com/rln/v1/network/privacy.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Sep 2019 18:54:51 GMT -->
</html>