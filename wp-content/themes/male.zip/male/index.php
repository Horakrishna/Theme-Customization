<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from trymanplus.net/manplus_v3/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 14 Oct 2019 19:24:13 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="googlebot" content="noindex" />
	<meta name="Slurp" content="noindex" />
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,700|Open+Sans:300,300i,400,600,700,700i,800|Oswald:300,400,700|Roboto+Slab:300,400,700|Sorts+Mill+Goudy"
	 rel="stylesheet" />

	<title>ManPlus - Maximum Sexual Benefits	</title>


	<link rel="icon" type="image/png" href="static/desktop_v2/images/favicons/favicon-32x32.png" sizes="32x32" />
	<link rel="icon" type="image/png" href="static/desktop_v2/images/favicons/favicon-16x16.png" sizes="16x16" />
	<link href="static/desktop_v2/images/favicons/apple-touch-icon-144x144-precomposed.png" rel="apple-touch-icon-precomposed"
	 sizes="144x144" />
	<link href="static/desktop_v2/images/favicons/apple-touch-icon-114x114-precomposed.png" rel="apple-touch-icon-precomposed"
	 sizes="114x114" />
	<link href="static/desktop_v2/images/favicons/apple-touch-icon-72x72-precomposed.png" rel="apple-touch-icon-precomposed"
	 sizes="72x72" />
	<link href="static/desktop_v2/images/favicons/apple-touch-icon-precomposed.png" rel="apple-touch-icon-precomposed" />



	

	<script>
		var iso_code = 'BD';
		var geodata = '{"country":"Bangladesh","country_iso_code":"BD","subdivisions":"Dhaka Division","subdivisions_iso_code":"C","city":"Dhaka","postal":"1209","status":"success"}';
		var basic_url = 'https://trymanplus.net/';
	</script>

		<script>
		var show_exit = true;
	</script>
	

  <script>
    var iso_code = 'BD';
    var geodata = '{"country":"Bangladesh","country_iso_code":"BD","subdivisions":"Dhaka Division","subdivisions_iso_code":"C","city":"Dhaka","postal":"1209","status":"success"}';
    var basic_url = 'https://trymanplus.net/';
    var static_url = 'https://trymanplus.net/static/';
    var post_country = '';
    var post_state = '';
    var post_billing_country = '';
    var post_billing_state = '';
    var post_payment_as_shipping = '';
    var confirmation_email = "";
    var IS_ORDER_PAGE = 0;
    var IS_CONFIRMATION_PAGE = 0;
    var DISABLE_SESSION_STORAGE = 0;
</script>

    <script>var show_exit = true;</script>

<?php wp_head();?>
</head>

<body class="">


	

<form action="" id="form1" name="formID" class="order-form re" method="post">
    <input type="hidden" name="token" value="4462658883" />
<input type="hidden" name="affid" value="" />
<input type="hidden" name="click_id" value="" />
<input type="hidden" name="netid" value="" />
<input type="hidden" name="referer" value="trymanplus.net/var/www-port/9005" />
<input type="hidden" name="subid1" value="" />
<input type="hidden" name="netaff" value="" />
<input type="hidden" name="c1" value="" />
<input type="hidden" name="c2" value="" />
<input type="hidden" name="language" value="en" />
<input type="hidden" name="subc" value="1" />
<input type="hidden" name="popups" value="on" />
<input type="hidden" name="affsub" value="" />
<input type="hidden" name="page" value="index" />
<input type="hidden" name="cr" value="" />
    <input type="hidden" name="special" value="on">
    <input type="hidden" name="total" value="on">
    <div id="container">
        <div class="tophdr" id="header">
            <div class="contentWrap" style="position:relative;">
                <p class="hdrtxt"><span>WARNING:</span> Due to extremely high media demand, there is limited supply of
                    Man Plus in stock as of
                    <b class="date-container"></b></p>
            </div>
        </div>
    </div>
    <div id="section1">
        <div class="sec1inner">
            <div class="contentWrap" style="position:relative;">
                <div class="lft-content">
                  
                    <i class="sprite sprite-top-logo s1-logo"></i>
                  
                    <i class="sprite sprite-top-txt top-txt"></i>
                    <p class="s1hding">Medical Strength Male Enhancement</p>
                    <p class="s1hding2">Get Maximum <br> <span>Sexual Benefits</span></p>
                    <div class="doctor">
                       
                        <i class="sprite sprite-rx rx"></i>
                    </div>
                    
                    <i class="sprite sprite-arrow s1-arrow"></i>
                    <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png"  height="343" alt=""
                         class="s1-prod1">
                    <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png" height="412" alt=""
                         class="s1-prod2">
                   
                    <i class="sprite sprite-us-seal us-seal"></i>
                    <ul class="s1list">
                        <li class="sprite sprite-icon"><span>Bigger &amp; Long-Lasting Erections </span><br>Maximum
                            pleasure &amp; intensified orgasms
                        </li>
                        <li class="sprite sprite-icon"><span>Surge In Sex Drive &amp; Energy </span><br>Ramps up stamina
                            &amp; power
                        </li>
                        <li class="sprite sprite-icon"><span>Increased Sexual Confidence </span><br>Experience vitality
                            &amp; peak performance
                        </li>
                    </ul>
                 
                </div>

                <div class="rgt-frm ordernow" id="ordernow">
                    <div class="frm-top">
                        <i class="sprite sprite-frm-top"></i>
                    </div>
                    <div class="formBody form-position">

                        <div class="form-holder frmElemts">
                            <label for="fields_fname">First Name</label>
                            <input type="text" name="first_name" placeholder="First Name"
                                   class="form-control required  first-name"/>
                            <div class="error-message">Please enter your First Name</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">Last Name</label>
                            <input type="text" name="last_name" placeholder="Last Name" class="form-control required "/>
                            <div class="error-message">Please enter your Last Name</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">Country</label>
                            <select class="form-control required " name="country" id="id_country">
                            </select>
                            <div class="error-message">Please enter your Country</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">Address</label>
                            <input type="text" name="address1" placeholder="Your Address"
                                   class="form-control required "/>
                            <div class="error-message">Please enter your Street Address</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">City</label>
                            <input type="text" name="city"
                                   placeholder="Your City"
                                   class="form-control required "/>
                            <div class="error-message">Please enter
                                your City</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">State:</label>
                            <select class="form-control required " name="state" id="id_state">
                            </select>
                            <div class="error-message">Please enter
                                your State/Province</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">Zip Code:</label>
                            <input type="text" name="zip_code"
                                   placeholder="Zip Code"
                                   class="form-control required "/>
                            <div class="error-message">Please enter
                                your Zip/Postal Code</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">Email</label>
                            <input type="text" name="email" placeholder="Email Address" class="form-control required "/>
                            <div class="error-message">Please enter your Email</div>
                            <div class="accept-icon"></div>
                        </div>
                        <div class="form-holder frmElemts">
                            <label for="fields_fname">Phone</label>
                            <input type="text" name="phone" placeholder="Phone" class="form-control required "/>
                            <div class="error-message">Please enter your Phone Number</div>
                            <div class="accept-icon"></div>
                        </div>

                    </div>

                    <div id="rushtop " class="frm-btm">
                        <i class="sprite sprite-lock lock"></i>
                        <button type="submit" class="button submit pulse"></button>

                        <i class="sprite sprite-frm-btm security"></i>
                    </div>

                </div>
            </div>
        </div>
</form>
<div id="section2">
    <div class="sec2inner">
        <div class="contentWrap" style="position:relative;">
            <p class="sec2hding"><span>The Sexual Health Divide </span><br>Are You Suffering From The Following Symptoms
            </p>
            <p class="s2txt">Leading surveys on sexual health and satisfaction levels among <br>
                American men have revealed the following: </p>
            <div class="red-box">
                <div class="s2box1">
                    <center><i class="sprite sprite-icon1-sec2"></i>
                        
                    </center>
                    <p class="s2box-txt">Say sexual health influences on overall life satisfaction</p>
                </div>
                <div class="s2box2">
                    <center><i class="sprite sprite-icon2-sec2"></i>
                      
                    </center>
                    <p class="s2box-txt">Suffer from Small<br>Penis Syndrome</p>

                </div>
                <div class="s2box3">
                    <center><i class="sprite sprite-icon3-sec2"></i>
                        
                    </center>
                    <p class="s2box-txt">Believe <br>embarrassment is a major sexual barrier</p>
                </div>
                <div class="s2box4">
                    <center><i class="sprite sprite-icon4-sec2"></i>
                     
                    </center>
                    <p class="s2box-txt">Avoid sex altogether because of lack of sexual confidence</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="section3">
    <div class="sec3inner">
        <div class="contentWrap" style="position:relative;">
            <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png" height="374" alt=""
                 class="s3-prod1">
            <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png" height="449" alt="" class="s3-prod2">
            <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/us-seal2.png" width="120" height="120" alt=""
                 class="satisfaction-seal">
            <p class="s3hding"><span>Man Plus  </span><br> Male Enhancement System</p>
            <p class="sec3txt"><b>Made with a blend of natural ingredients, <span>Man Plus   is a male enhancement system</span>
                    that has
                    been formulated to restore your sexual youth and performance and help you experience an intense,
                    blissful & powerful
                    sex life. </b><br><br>
                <strong>Man Plus </strong> dual action formula not only gives you an instant surge in sexual power &
                performance - but also treats the
                root cause of sexual dysfunctions, ensuring that you are able to satisfy your partner, consistently!
                Made with herbal extracts,
                <b>Man Plus </b> is completely safe to use and is free from any harmful side effects. </p>
            <p class="sec3txt2">Triple IntenSity<br><span>Male Enhancement </span><br>For maximum Results</p>
            <p class="sec3txt3">The pro-sexual nutrient matrix in Man Plus helps boost the 3S's of Sex - Size, Stamina &
                Satisfaction,
                helping you peak perform and pleasure your partner just like you did in your 20's!</p>
            <p class="sec3txt4"><b>Man Plus </b> is proudly made in the United States of America at a certified
                manufacturing facility to meet
                statutory industry standards. Every purchase is backed by a Satisfaction Guarantee, so that you can
                enjoy the benefits with confidence. </p>
            <div class="btn-strip">
                <p class="btn-txt"><span>ORDER YOUR Man Plus TODAY!</span><br> Experience Sexual Power, Pleasure &
                    Performance</p>
                <a href="#form1" class="cta"><i class="sprite sprite-button sec3btn pulse"></i>
                    <!-- <img src="/static/desktop_v3/images/button.png" width="275" height="70" alt=""  class="sec3btn pulse"> -->
                </a>
            </div>
        </div>
    </div>
</div>
<div id="section4">
    <div class="contentWrap">
        <p class="s4hding"><span>THE SCIENCE BEHIND </span> <br>BETTER, LONGER & MORE INTENSE SEX!</p>
        <!-- <img src="/static/desktop_v3/images/clink-seal.png" width="156" height="156" alt=""  class="s4seal"> -->
        <i class="sprite sprite-clink-seal s4seal"></i>
        <p class="s4txt"> <span>The blood flow to the penis is responsible for erections while the <br>holding capacity of the penis
        chambers is what influences sexual stamina <br>and staying power. <b>Man Plus  </b> helps boost both to help you and your partner
        <br>partner enjoy intense orgasms and complete satisfaction.</span><br><br>
            <strong>Man Plus </strong> pro-sexual nutrient blend is quickly absorbed into the bloodstream to stimulate
            Nitric Oxide production - this in
            turn boosts the flow of blood to the penile chambers helping you enjoy harder and stronger erections. It
            also expands the penis chambers allowing it to hold more blood in order to drastically increase sexual
            stamina, strength
            and power. </p>

        <p class="s4txt2"><b>Man Plus </b> utilizes a breakthrough rapid absorption and extended release technology.
            Rapid absorption of the
            ingredients into the bloodstream aid in delivering instant surge of sexual power while the extended release
            technology
            delivers sustained results that help you enjoy on command erections and stamina to last all night long. </p>

        <!-- <img src="/static/desktop_v3/images/s4img.png" width="325" height="369" alt=""  class="s4img"> -->
        <i class="sprite sprite-s4img s4img"></i>
        <p class="s4txt3"><span>Man Plus  </span> works by triggering the two mechanisms known <br>to increase penis
            size, function and
            performance. These are:</p>
        <p class="s4txt4">An increase in "free" testosterone and</p>
        <p class="s4txt5">Nitric Oxide production to the penis.</p>
        <p class="s4txt6"><span>Man Plus   is the only product that does both.</span> It contains the<br>most potent
            nitric oxide stimulators
            which maximize the delivery of the<br>active ingredients to your penile tissue giving you firmer, longer
            erections.</p>
        <div class="s4btn-strip">
            <p class="btn-txt"><span>ORDER YOUR Man Plus TODAY!</span><br> Experience Sexual Power, Pleasure &
                Performance</p>
            <a href="#form1" class="cta"><i class="sprite sprite-button sec3btn pulse"></i>
                <!-- <img src="/static/desktop_v3/images/button.png" width="275" height="70" alt=""  class="sec3btn pulse"> -->
            </a>
        </div>
    </div>
</div>
<div id="section5">
    <div class="sec5inner">
        <div class="contentWrap">
            <p class="s5hding"><span>The Benefits of Man Plus  </span> <br>ADVANCED MALE ENHANCEMENT!</p>
            <p class="sec5txt"><span>Man Plus   Male Enhancement System</span> offers multiple sexual health benefits to
                help you
                <br>enjoy hard erections, increased stamina and peak performance.</p>
            <div class="s5benefits">
                <div class="s5box1">
                    <p class="bnft-txt">IMPROVED LIBIDO & SEX DRIVE</p>
                    <p class="bnft-txt2">Get ready to<br>experience a torrent of desire & passion with <b>Man Plus </b>,
                        which replenishes sexual
                        energy stores across the body like never before.</p>
                </div>
                <div class="s5box2">
                    <p class="bnft-txt">INCREASED STAYING <br>POWER</p>
                    <p class="bnft-txt2">Bid goodbye to pre-<br>mature ejaculations! <b>Man Plus </b> floods your penile
                        chambers with a gush of
                        blood letting you last 5X more than usual.</p>
                </div>
                <div class="s5box5">
                    <p class="bnft-txt">BIGGER, HARDER & LONGER ERECTIONS</p>
                    <p class="bnft-txt2"><b>Man Plus </b> lets you achieve rock hard erections on command helping you
                        and your partner enjoy
                        insane sexual sessions, whenever you desire.</p>
                </div>
                <div class="s5box4">
                    <p class="bnft-txt">IMPROVED SEXUAL CONFIDENCE</p>
                    <p class="bnft-txt2">Equipped with youthful sexual powers & energy, you are sure to experience
                        sexual confidence
                        like never before, Man Plus gives you greater success with the most desirable women!</p>
                </div>
                <div class="s5box3">
                    <p class="bnft-txt">INCREASED <br>PENIS <br>SIZE</p>
                    <p class="bnft-txt2">An increase in penile chamber capacity and regular boost in blood flow may help
                        add those inches
                        to your penis size, both length & girth wise.</p>
                </div>
            </div>
            <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png"height="320" alt=""
                 class="s5-prod1">
            <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png"  height="320" alt=""
                 class="s5-prod2">
            <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png" height="385" alt="" class="s5-prod3">
            <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/satisfaction-seal.png" width="127" height="108" alt=""
                 class="s5img">
            <!-- <img src="/static/desktop_v3/images/one-img.png" width="79" height="118" alt=""  class="s5img2"> -->
            <i class="sprite sprite-one-img s5img2"></i>
            <p class="s5lft-txt"><span>Our product backed with a</span><br>100% Satisfaction <br>Guarantee!</p>
            <p class="s5rgt-txt"><span>THE NUMBER ONE</span><br>MALE ENHANCEMENT<br><b> PILL IN THE US</b></p>
            <div class="clearall"></div>
            <div class="s5btn-strip">
                <p class="btn-txt"><span>ORDER YOUR Man Plus TODAY!</span><br> Experience Sexual Power, Pleasure &
                    Performance</p>
                <a href="#form1" class="cta"><i class="sprite sprite-button sec3btn pulse"></i>
                    <!-- <img src="/static/desktop_v3/images/button.png" width="275" height="70" alt=""  class="sec3btn pulse"> -->
                </a>
            </div>
        </div>
    </div>
</div>
<div id="section6">
    <div class="sec6inner">
        <div class="contentWrap" style="position:relative;">
            <p class="s6hding"><span>Powerful Ingredients</span> <br>For Bigger Results </p>
            <i class="sprite sprite-natural-seal natural-seal"></i>
            <div class="sec6lft">
                <p class="s6ingrnts1">L-Arginine</p>
                <p class="s6txt">Stimulates nitric oxide production to boost blood circulation to the penis helping
                    achieve biggers and stronger erections. </p>

                <p class="s6ingrnts2">Ginko Biloba Extarct</p>
                <p class="s6txt" style="padding-top:84px;">An aphrodisiac, it helps boost male sexual drive and libido.
                    It also supports healthy
                    testosterone levels. </p>

            </div>
            <div class="sec6rgt">
                <p class="s6ingrnts3">Nettle Extract</p>
                <p class="s6txt2">Called the "Viagra of Amazon", this herbal extract <br>replenishes sexual energy
                    stores
                    for improved <br>strength and stamina. </p>
                <div class="clearall"></div>

                <div class="lftingrnts">
                    <p class="s6ingrnts4">Tongkat <br>Ali Extract</p>
                    <p class="s6txt3">Positively influences mood patterns to reduce stress and promote relaxation,
                        enabling men to perform at their peak. </p>
                </div>
                <div class="rgtingrnts">
                    <p class="s6ingrnts5">Saw Palmetto <br>Berry</p>
                    <p class="s6txt3">Helps increase staying power ensuring you and your partner enjoy longer
                        sessions with intense orgasms. </p>
                </div>
                <div class="clearall"></div>
                <p class="s6ingrnts6">Horny Goat Weed <br>Extract</p>
                <p class="s6txt2">Works synergistically with the other pro-sexual nutrients to boost blood flow to
                    the penile chambers for improved erections. It also helps expand the chambers to increase blood
                    holding capacity and in-turn staying power.</p>
            </div>
            <div class="clearall"></div>
            <p class="s6btm-txt"><span>Bioperine™</span><br>Helps support the formula's quick absorption technology.
                This allows the key herbal ingredients that support male enhancement to be absorbed quickly into the
                blood
                stream, triggering an instant boost in sexual energy, stamina and erections. </p>
            <div class="s6btn-strip">
                <p class="btn-txt"><span>ORDER YOUR Man Plus TODAY!</span><br> Experience Sexual Power, Pleasure &
                    Performance</p>
                <a href="#form1" class="cta"><i class="sprite sprite-button sec3btn pulse"></i>
                </a>
            </div>
        </div>
    </div>
</div>
<div id="section7">
    <div class="sec7inner">
        <div class="contentWrap" style="position:relative">
            <p class="s7hding"><span>REAL MEN, REAL RESULTS</span><br>Success Stories From Our Customers </p>
            <p class="s7txt"><span>Man Plus   has helped hundreds of men across all ages</span> beat sexual dysfunction
                <br>and enjoy a
                fuller and more satisfying sex life.</p>
            <div class="slider">
                <div class="slide1">
                    <div class="lft-box">
                        <i class="sprite sprite-man1 sliderimg"></i>
                        <i class="sprite sprite-star star"></i>
                        <p class="sldr-tstimnl">“<b>Man Plus </b> is truly the best male enhancement system in the
                            market!
                            Unlike other products that have synthetics, <b>Man Plus </b> is made with herbal extracts
                            and botanicals
                            which have been clinically proven to boost virility. I did a
                            thorough research before picking up the product and the results have been truly phenomenal.
                            Highly recommended. ”</p>
                        <p class="tstmnl-name"><span>- Carlos Velez, 43 </span></p>

                    </div>
                    <div class="rgt-box">
                        <p class="clearall"></p>
                      
                        <i class="sprite sprite-man2 sliderimg"></i>
                        <i class="sprite sprite-star star"></i>
                        <p class="sldr-tstimnl">“The age related ED issues were very frustrating and no pill seemed to
                            work! When my friend
                            recommended <b>Man Plus </b>, I decided I will give it a try and I am glad I did! It has
                            helped me boost my sexual stamina,
                            size and confidence. And guess who is a bigger fan of <b>Man Plus </b> than me, my wife! ”
                        </p>
                        <p class="tstmnl-name2"><span>- Rob Greco, 54</span></p>
                    </div>
                </div>
                <div class="slide2">
                    <div class="lft-box">
                        <i class="sprite sprite-man3 sliderimg"></i>
                        <i class="sprite sprite-star star"></i>
                        <p class="sldr-tstimnl">“Its great to know that my favorite male enhancement supplement is now
                            available in the market
                            without a prescription! I have been using <b>Man Plus </b> for a few months now and the
                            results have been truly "huge"! I am able
                            to enjoy harder erections, increased sexual drive and stamina, which lets me enjoy love
                            making just like I used to when
                            I was in my 30s! ”</p>
                        <p class="tstmnl-name" style="padding:25px 0 0 21px;"><span>- Vincent Harper, 49</span></p>

                    </div>
                    <div class="rgt-box">
                        <p class="clearall"></p>
                        <i class="sprite sprite-man4 sliderimg"></i>
                        <i class="sprite sprite-star star"></i>
                        <p class="sldr-tstimnl">“Age related decline in sexual health along with onset of mild ED had
                            left me pretty shattered.
                            I came across <b>Man Plus </b> on a very reputed blog for male health and decided to give it
                            a try. It has been the best decision
                            I ever made. My sex drive has really taken off, my erections are back to their firm and the
                            increase in sexual stamina
                            is just amazing! ”</p>
                        <p class="tstmnl-name2" style="padding:25px 0 0 21px;"><span>- Sean Carter, 56</span></p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<div id="section8">
    <div class="contentWrap" style="position:relative">
        <i class="sprite sprite-top-logo s8-logo"></i>
        <i class="sprite sprite-rx s8no-pres"></i>
        <p class="s8hding">Medical Strength Male Enhancement</p>
        <p class="s8hding2">Get Maximum <br> <span>Sexual Benefits</span></p>
        <i class="sprite sprite-us-seal s8seal2"></i>
        <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png"  height="341" alt=""
             class="s8-prod1">
        <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png"  height="341" alt=""
             class="s8-prod2">
        <img src="<?php echo get_template_directory_uri();?>/static/desktop_v3/images/bottle.png" height="470" alt=""
             class="s8-prod3">
        <ul class="s8list">
            <li class="sprite sprite-icon"><span>Bigger & Long-Lasting Erections </span><br>Maximum pleasure &
                intensified orgasms
            </li>
            <li class="sprite sprite-icon"><span>Surge In Sex Drive & Energy </span><br>Ramps up stamina & power</li>
            <li class="sprite sprite-icon"><span>Increased Sexual Confidence </span><br>Experience vitality & peak
                performance
            </li>
        </ul>
        <a href="#form1" class="cta"><i class="sprite sprite-button sec8btn pulse"></i>
        </a>

    </div>
</div>



<div id="footer">
    <div class="contentWrap">
        <p class="ftrtxt">
            <!-- This product has not been evaluated by the FDA. This product is not intended to diagnose, treat, cure or prevent any disease.
            Results in description and testimonials may not be typical results and individual results may vary.
            This product is intended to be used in conjunction with a healthy diet and regular exercise.
            Consult your physician before starting any diet, exercise program, and taking any diet pill to avoid any health issues. -->


            Representations regarding the efficacy and safety of Man Plus Male Enhancement have not been evaluated by the Food
            and Drug Administration. The FDA only evaluates foods and drugs, not supplements like these products.
            These products are not intended to diagnose, prevent, treat, or cure any disease. <a target="_blank" href="https://www.ncbi.nlm.nih.gov/pubmed/23754792" style="color: blue;">Click here </a> to find
            evidence of a test, analysis, research, or study describing the benefits, performance or efficacy of
            Man Plus Male Enhancement based on the expertise of relevant professionals.


            <br><br>
            <a href="javascript:void(0)" class="open-popup-link" id="terms">TERMS AND CONDITIONS</a> |
            <a href="javascript:void(0)" class="open-popup-link" id="privacy">PRIVACY POLICY</a> |
            <a href="javascript:void(0)" class="open-popup-link" id="contact-us">CONTACT US</a>

            <br>
            Copyright © 2019 Man Plus. All rights reserved.</p>
    </div>
</div>


<!--popup loading wrapper-->
	<section class="popup-loading-wrapper" style="display: none">
		<div class="popup">
			<figure class="product-image">

			</figure>
			<p>Reserving Your Bottle Of</p>
			<h2>Man Plus Vixea</h2>
			<img src="<?php echo get_template_directory_uri();?>/static/desktop/images/icon-loading.png" alt="" class="loading-image"/>
		</div>
	</section>
	<!--end popup loading wrapper-->
<!--popup wrapper-->
<section class="popup-wrapper">

    <!--popup contact us-->
<div class="popup" id="popup-contact-us">
	<div class="popup-inner">
		<a href="javascript:void(0)" class="close-popup-link"></a>

		<h2>Contact Us</h2>
		<p>Have a question you’d like to ask? We’re here to address any inquiry you may have.<br />Simply fill out the form below and we will get back to you within a few hours.</p>

		<form action="#" class="form-popup" id="form-contact-us">
			<input type="hidden" name="page" value="popup_contact_us" />
			<input type="hidden" name="lang_contact_us" value="en" />
			<div class="form-holder">
				<input type="text" name="contactName" placeholder="Name">
				<div class="error-message">Please enter your Name</div>
				<div class="accept-icon"></div>
			</div>
			<div class="form-holder">
				<input type="text" name="contactEmail" placeholder="Email Address">
				<div class="error-message">Please enter your Email Address</div>
				<div class="accept-icon"></div>
			</div>
			<div class="form-holder">
				<input type="text" name="contactPhone" placeholder="Telephone">
				<div class="error-message">Please enter your Telephone</div>
				<div class="accept-icon"></div>
			</div>
			<div class="form-holder">
				<select name="contactMsgTopic">
					<option>Message Topic</option>
					<option>Customer Service</option>
					<option>Billing</option>
					<option>Business Offers</option>
					<option>Report Spam</option>
					<option>Affiliate</option>
				</select>
				<div class="error-message">Please select Message Topic</div>
				<div class="accept-icon"></div>
			</div>
			<div class="form-holder">
				<textarea name="contactMessage" cols="30" rows="10" placeholder="Enter your Message here"></textarea>
				<div class="accept-icon"></div>
			</div>
			<div class="form-holder">
				<input type="text" name="captcha" placeholder="Captcha" class="" style="display: inline-block; margin-right: 10px;">
				<img class="captcha" title="Refresh" style="display: inline-block; vertical-align: top;" src="indexe5b5.html?captcha=new&amp;r=1571081052"/>
				<div class="error-message">Captcha is incorrect.</div>
				<div class="accept-icon"></div>
			</div>
			<button type="submit" class="button">Send</button>
		</form>

		<footer><a href="javascript:void(0)" class="button small green close-popup-link">Close</a></footer>

	</div>
</div>
<!--end popup contact us-->


<script>
    $(document).ready(function() {

        try {
            $('#form-contact-us').validate({

                submitHandler: function(form) {
                    send_contact_us($('#form-contact-us'), $('input[name="lang_contact_us"]').val());
                },

                invalidHandler: function(event, validator) {
                    logging($('#form-contact-us'));
                    show_exit = true;
                    $.each($('#form-contact-us').children('div'), function( index, elem) {
                        $(elem).removeClass('has-error').addClass('accept');
                        $(elem).find('input').removeClass('error');
                    });
                    var errors = validator.numberOfInvalids();
                    if (errors) {
                        $('html, body').animate({
                            scrollTop: $('#form-contact-us').offset().top
                        }, 1000);
                    } else {
                        show_exit = false;
                    }
                },

                errorPlacement: function(error, element) {

                    if ($(element).hasClass('error')) {
                        $(element).closest('div').addClass('has-error').removeClass('accept');
                        $(element).addClass('error')
                    } else {
                        $(element).closest('div').removeClass('has-error').addClass('accept');
                        $(element).removeClass('error')
                    }
                },

                success: function(label) {
                },

                rules: {
                    contactName: {
                        required: true,
                    },
                    contactEmail: {
                        required: true,
                        email: true
                    },
                    contactPhone: {
                        required: true,
                        minlength: 10,
                        maxlength: 20
                    },
                    contactMsgTopic: {
                        checkMsgTopic: 'default'
                    },
                    contactMessage: 'required',
                    captcha: "required"
                }
            });

            $.validator.addMethod( 'checkMsgTopic', function(value) {
                return value != 'Message Topic';
            });
        } catch(e) {
            sendJsErrorInTry('#form-contact-us', e, 'contact_us_popup');
        }
    });

</script>    <!--popup disclaimer-->
		<div class="popup" id="popup-disclaimer">
			<div class="popup-inner">
				<a href="javascript:void(0)" class="close-popup-link"></a>
				<header><h2>Disclaimer</h2></header>
				<p>This product is not for use by or sale to persons under the age of 18. This product should be used only as directed on the label. It should not be used if you are pregnant or nursing. Consult with a physician before use if you have a serious medical condition or use prescription medications. A Doctor's advice should be sought before using this and any supplemental dietary product. All trademarks and copyrights are the property of their respective owners and are not affiliated with nor do they endorse this product. These statements have not been evaluated by the FDA. This product is not intended to diagnose, treat, cure or prevent any disease. Individual weight loss results will vary. By using this site you agree to follow the Privacy Policy and all Terms & Conditions printed on this site. Void Where Prohibited By Law.</p>
				<footer><a href="javascript:void(0)" class="button small green close-popup-link">Close</a></footer>
			</div>
		</div>
		<!--end popup disclaimer-->    <!--popup pravicy-->
<div class="popup" id="popup-privacy">
	<div class="popup-inner">
		<a href="javascript:void(0)" class="close-popup-link"></a>
		<header>
			<h2>Privacy Policy</h2>
		</header>
		<h4>Man Plus – Privacy Statement & Terms of Use</h4>
		<h4>In using this website you are deemed to have read and agreed
			to the following terms and conditions:</h4>
		<p>The following terminology applies to these Terms and
			Conditions, Privacy Statement and Disclaimer Notice and any or all
			Agreements: "Client", “You” and “Your” refers to you, the person
			accessing this website and accepting the Company’s terms and
			conditions. “ Man Plus ”, "The Company", “Ourselves”, “We” and "Us",
			refers to our Company. “Party”, “Parties”, or “Us”, refers to both
			the Client and ourselves, or either the Client or ourselves. All
			terms refer to the offer, acceptance and consideration of payment
			necessary to undertake the process of our assistance to the Client in
			the most appropriate manner, whether by formal meetings of a fixed
			duration, or any other means, for the express purpose of meeting the
			Client’s needs in respect of provision of the Company’s stated
			services/products, in accordance with and subject to, prevailing
			English Law. Any use of the above terminology or other words in the
			singular, plural, capitalisation and/or he/she or they, are taken as
			interchangeable and therefore as referring to same.</p>
		<h4>Privacy Statement</h4>
		<p>Man Plus is committed to protecting your privacy.
			Authorized employees within the company on a need to know basis only
			use any information collected from individual customers. We
			constantly review our systems and data to ensure the best possible
			service to our customers.</p>
		<h4>Confidentiality</h4>
		<p>Any information concerning the Client and their respective
			Client Records may be passed to third parties. However, Client
			records are regarded as confidential and therefore will not be
			divulged to any third party. Clients have the right to request sight
			of, and copies of any and all Client Records we keep, on the proviso
			that we are given reasonable notice of such a request. Clients are
			requested to retain copies of any literature issued in relation to
			the provision of our services. Where appropriate, we shall issue
			Client’s with appropriate written information, handouts or copies of
			records as part of an agreed contract, for the benefit of both
			parties.</p>
		<p>
			<b><i>We will not sell, share, or rent your personal
					information to any third party or use your e-mail address for
					unsolicited mail. Any emails sent by this Company will only be in
					connection with the provision of agreed services and products.</i></b>
		</p>
		<h3>DISCLAIMER</h3>
		<h4>Exclusions and Limitations</h4>
		<p>The information on this web site is provided on an "as is"
			basis. To the fullest extent permitted by law, this Company:</p>
		<p>- excludes all representations and warranties relating to this
			website and its contents or which is or may be provided by any
			affiliates or any other third party, including in relation to any
			inaccuracies or omissions in this website and/or the Company’s
			literature; and</p>
		<p>- excludes all liability for damages arising out of or in
			connection with your use of this website. This includes, without
			limitation, direct loss, loss of business or profits (whether or not
			the loss of such profits was foreseeable, arose in the normal course
			of things or you have advised this Company of the possibility of such
			potential loss), damage caused to your computer, computer software,
			systems and programs and the data thereon or any other direct or
			indirect, consequential and incidental damages.</p>
		<p>This Company does not however exclude liability for death or
			personal injury caused by its negligence. The above exclusions and
			limitations apply only to the extent permitted by law. None of your
			statutory rights as a consumer are affected.</p>
		<h4>Log Files</h4>
		<p>We use IP addresses to analyse trends, administer the site,
			track user’s movement, and gather broad demographic information for
			aggregate use. IP addresses are not linked to personally identifiable
			information. Additionally, for systems administration, detecting
			usage patterns and troubleshooting purposes, our web servers
			automatically log standard access information including browser type,
			access times/open mail, URL requested, and referral URL. This
			information is not shared with third parties and is used only within
			this Company on a need-to-know basis. Any individually identifiable
			information related to this data will never be used in any way
			different to that stated above without your explicit permission.</p>
		<h4>Cookies</h4>
		<p>Like most interactive web sites this Company’s website uses
			cookies to enable us to retrieve user details for each visit. Cookies
			are used in some areas of our site to enable the functionality of
			this area and ease of use for those people visiting. Some of our
			affiliate partners may also use cookies.</p>
		<h4>Links to this website</h4>
		<p>You may not create a link to any page of this website without
			our prior written consent. If you do create a link to a page of this
			website you do so at your own risk and the exclusions and limitations
			set out above will apply to your use of this website by linking to
			it.</p>
		<h4>Links from this website</h4>
		<p>We do not monitor or review the content of other party’s
			websites which are linked to from this website. Opinions expressed or
			materials appearing on such websites are not necessarily shared or
			endorsed by us and should not be regarded as the publisher of such
			opinions or material. Please be aware that we are not responsible for
			the privacy practices, or content, of these sites. We encourage our
			users to be aware when they leave our site & to read the privacy
			statements of these sites. You should evaluate the security and
			trustworthiness of any other site connected to this site or accessed
			through this site yourself, before disclosing any personal
			information to them. This Company will not accept any responsibility
			for any loss or damage in whatever manner, howsoever caused,
			resulting from your disclosure to third parties of personal
			information.</p>
		<h4>Copyright Notice</h4>
		<p>Copyright and other relevant intellectual property rights exist
			on all text relating to the Company’s services and the full content
			of this website.</p>
		<h4>Communication</h4>
		<p>We have several different e-mail addresses for different
			queries. These, & other contact information, can be found on our
			Contact us link on our website.</p>
		<h4>General</h4>
		<p>By accessing this website you consent to these terms and
			conditions. If any of these terms are deemed invalid or unenforceable
			for any reason (including, but not limited to the exclusions and
			limitations set out above), then the invalid or unenforceable
			provision will be severed from these terms and the remaining terms
			will continue to apply. Failure of the Company to enforce any of the
			provisions set out in these Terms and Conditions, or failure to
			exercise any option to terminate, shall not be construed as waiver of
			such provisions and shall not affect the validity of these Terms and
			Conditions or of any Agreement or any part thereof, or the right
			thereafter to enforce each and every provision. These Terms and
			Conditions shall not be amended, modified, varied or supplemented
			except in writing and signed by duly authorised representatives of
			the Company.</p>
		<h4>Notification of Changes</h4>
		<p>The Company reserves the right to change these conditions from
			time to time as it sees fit and your continued use of the site will
			signify your acceptance of any adjustment to these terms. If there
			are any changes to our privacy policy, we will announce that these
			changes have been made on our home page and on other key pages on our
			site. If there are any changes in how we use our site customers’
			Personally Identifiable Information, notification by e-mail or postal
			mail will be made to those affected by this change. Any changes to
			our privacy policy will be posted on our web site 30 days prior to
			these changes taking place. You are therefore advised to re-read this
			statement on a regular basis</p>
		<p>
			<b><i>These terms and conditions form part of the Agreement
					between the Client and Ourselves. Your accessing of this website
					and/or undertaking of a booking or Agreement indicates your
					understanding, agreement to and acceptance, of the Disclaimer
					Notice and the full Terms and Conditions contained herein. Your
					statutory Consumer Rights are unaffected.</i></b>
		</p>
		<footer>
			<a href="javascript:void(0)"
				class="button small green close-popup-link">Close</a>
		</footer>
	</div>
</div>
<!--end popup pravicy-->    <!--popup shipping-->
<div class="popup" id="popup-shipping">
	<div class="popup-inner">
		<a href="javascript:void(0)" class="close-popup-link"></a>
		<header>
			<h2>Shipping Policy</h2>
		</header>
		<h3>Shipping Methods</h3>
		<p>We ship with USPS Priority Air Mail. Delivery takes 2-4
			business days depending on your location. For international orders,
			it can take upto an additional 3-5 business days. All orders are
			shipped with insurance and delivery is guaranteed.</p>
		<h3>RETURNS</h3>
		<p>All orders are secured with a 30-Day Money Back Guarantee.</p>
		<p>To return your order for a full refund, simply contact us for a
			RMA Return Merchandise Authorization number, and we'll give you
			instructions on how to return your order to our warehouse for a full
			refund.</p>
		<footer>
			<a href="javascript:void(0)"
				class="button small green close-popup-link">Close</a>
		</footer>
	</div>
</div>
<!--end popup shipping-->    <!--popup terms-->
<div class="popup" id="popup-terms">
	<div class="popup-inner">
		<a href="javascript:void(0)" class="close-popup-link"></a>
		<header>
			<h2>Terms and Conditions of Use</h2>
		</header>
		<h3>CAREFULLY READ AND UNDERSTAND THESE TERMS BEFORE ORDERING ANY
			PRODUCT THROUGH THIS WEBSITE</h3>
		<p>ATTENTION: This is a legal agreement (the "Agreement") between
			You, the individual, company or organization ("you," "your," or
			"Customer") and our website ("we," "our", "Company"). By ordering,
			accessing, using or purchasing Man Plus ("Product") through this
			website or related websites (collectively the "Website"), you are
			agreeing to be bound by, and are becoming a party to, this Agreement.
			We may at our sole and absolute discretion change, add, modify, or
			delete portions of this Agreement at any time without notice. It is
			your sole responsibility to review this Agreement for changes prior
			to use of the Website or purchase of the Product.</p>
		<p>IT IS STRONGLY RECOMMENDED THAT YOU REVIEW THIS DOCUMENT IN ITS
			ENTIRETY BEFORE ACCESSING, USING OR BUYING ANY PRODUCT THROUGH THE
			WEBSITE AND PRINT A COPY FOR YOUR RECORDS.</p>
		<h3>Health Disclaimer</h3>
		<p>This product is not intended to diagnose, treat, cure or
			prevent any disease. If you are pregnant, nursing, taking medication,
			or have a history of heart conditions we suggest consulting with a
			physician before using any of our products. The results on all
			products are not typical and not everyone will experience these
			results. Toll Free Customer Service phone: +44-808-189-6334 (Support Line)</p>
		<h3>Terms and Conditions</h3>
		<p>Please carefully read the following terms and conditions as
			when you purchase any of the products from our web site, you agree
			and are bound to the following terms and conditions.</p>
		<p>This Agreement is between our website and you ("you" or
			"Customer") This Section sets forth the terms and conditions which
			apply to the use by you of the website (as defined below) and any
			other subscription product or service offered for sale by our website
			and/or its affiliates.</p>
		<p>The right to use any product or service offered by our website
			is personal to you and is not transferable to any other person or
			entity. We reserve the right to make changes to the website,
			policies, and these terms at any time without notice.</p>
		<h3>Disclaimer of Warranty; Limitation of Liability</h3>
		<p>This website neither endorses nor is responsible for the
			accuracy or reliability of any opinion, advice or statement on the
			website. Under no circumstances are we liable for any loss or damage
			caused by your reliance on information obtained through the content
			on the website. It is your responsibility to evaluate the accuracy,
			completeness or usefulness of any information, opinion, advice or
			other content available through the website. Please seek the advice
			of professionals, as appropriate, regarding the evaluation of any
			specific information, opinion, advice or other content, including but
			not limited to financial, health, or lifestyle information, opinion,
			advice or other content.</p>
		<h3>Indemnification</h3>
		<p>You agree to defend, indemnify and hold harmless our website,
			its affiliates and their respective directors, officers, employees
			and agents from and against all claims and expenses, including
			attorneys' fees, arising out of the use by you of the website,
			including claims by other users, access, products or memberships.</p>
		<h3>Refund/Return Policy</h3>
		<p>In order to obtain your full refund, contact customer service
			by phone and obtain an RMA (Return Merchandise Authorization) number
			to place on your package. Write this number on the outside of the
			shipping package, and send the product back to our warehouse at the
			address provided to you, and within thirty (30) days of the date you
			originally ordered the product. In order for your full refund to be
			processed the product must arrive at our fulfillment facility within
			thirty (30) days of the original purchase date and NOT be opened or
			used. You pay for return shipping. There is a $5.00 restocking fee
			per unit you are returning. This fee will be taken out of the refund
			issued. Once our warehouse has received the returned package, you
			will be issued a refund. Your refund will be credited back to the
			same credit card used to make the purchase. Refunds are issues within
			48 hours, and may take up to 3-5 business days to show in your
			statement, depending on the speed of the processing bank.</p>
		<p>
			You may request a refund by calling +44-808-189-6334 (Support Line)<br />Monday to
			Friday 9AM to 9PM PST<br />Saturday 9AM-6PM.
		</p>
		<p>Returns must be sent with your RMA number written on the
			packaging to:</p>
		<p>RMA Returns</p>
		<p>The Refund will show on your Credit Card statement as Man Plus, and
			you will receive a confirmation email from our warehouse at the time
			when your refund has been issued.</p>
		<h3>Toll Free Customer Service phone: +44-808-189-6334 (Support Line)</h3>
		<p>Be sure to write your RMA # on the outside of the envelope for
			proper account credit.</p>
		<p>We are not responsible for lost or stolen items. We recommend
			all returned items to be sent using some type of delivery
			confirmation system to ensure proper delivery. After the shipping
			department receives your return, it generally takes 48 hours for your
			refund to be processed.</p>
		<p>Please note the following terms:</p>
		<ul>
			<li>Packages marked "Return to Sender" will NOT be processed or
				refunded. Returned packages will only be refunded with an RMA number
				that was provided by our Customer Service department. Call Customer
				Service at +44-808-189-6334 (Support Line) for your RMA number. RMA numbers are good
				for 30 days.</li>
			<li>Refunds will only be issued to the same credit card to which
				they were charged.</li>
			<li>Customer is responsible for return shipping charges.</li>
			<li>After the warehouse receives your return, it generally takes
				2 business days to process your return. Please keep in mind that
				your bank typically posts credits in the billing cycle in which it
				was received. Therefore, the number of days it takes for the credit
				to post to your account may vary, depending on your banking
				institution's billing and credit schedule.</li>
			<li>Our customer service representatives may offer you a
				discounted price or partial refund if you call to cancel your
				account. You may accept or reject the discounted price or partial
				refund. If you reject the discount or partial refund, then in order
				to obtain your refund you will be required to return the product to
				us using an RMA number as described above. If you accept the
				discount or partial refund, you agree to waive your right to return
				this order.</li>
		</ul>
		<h3>Legal Disclaimer</h3>
		<p>These products are not intended to diagnose, treat, cure or
			prevent any illness or disease. Consult with your physician for
			diagnosis or treatment. Use herbs as per instructions and always
			watch for any allergic reactions.</p>
		<p>The information presented on this site is not presented with
			the intention of diagnosing any disease or condition or prescribing
			any treatment. It is offered as information only, for use in the
			maintenance and promotion of good health in cooperation with a
			licensed medical practitioner.</p>
		<p>In the event that any individual should use the information
			presented on this website without a licensed medical practitioner's
			approval, that individual will be diagnosing for him or herself.</p>
		<h3>Shipping</h3>
		<p>The standard ground mail service is shipped via United States
			Postal Service First Class Mail. Packages will arrive within 3-5
			business days. Please be advised that shipments are not sent out on
			Saturdays, Sundays, or any Holidays. We do not guarantee arrival
			dates or times.</p>
		<h3>Additional Taxes and Duties</h3>
		<p>Depending on your location, you may be required to pay
			applicable taxes and duties in relation to your state, province or
			country.</p>
		<h3>Ingredients</h3>
		<p>All products sold on the website are produce and manufactured
			in an FDA Approved facility that is GMP Certified. Raw materials are
			of the highest quality for optimum potency.</p>
		<p>Man Plus Proprietary Blend: Standardized 80% Man Plus
			1000mg.</p>
		<p>Smart Cleanse Detox Proprietary Blend: Flaxseed, Oat Bran,
			Papya Leaf Extract, Black Walnut Hull, Prune Extract, Aloe Vera, L.
			Acidophilus, Apple Pectin</p>
		<h3>Herbal Safety Guidelines</h3>
		<p>Before using an herb you are unfamiliar with, find out its
			medicinal properties. Research it thoroughly and/or consult with an
			appropriately qualified practitioner or expert. If you are taking
			prescription drugs, or have a medical condition, check with an
			appropriately qualified practitioner before using herbs medicinally.
			Herbs have shown overwhelming evidence that they work. Just because a
			small amount works well does NOT mean that more is better. As
			individuals we all have different constitutions, sensitivities,
			allergic reactions and possible health conditions. The following are
			merely guidelines. They include herbs offered on our websites. This
			list does not help with administering information on possible
			interactions and contraindications with prescription medicine. This
			needs to be discussed with your physician.</p>
		<p>Should I check with my doctor or healthcare provider before
			using a supplement? This is a good idea, especially for certain
			population groups. Dietary supplements may not be risk-free under
			certain circumstances. If you are pregnant, nursing a baby, or have a
			chronic medical condition, such as, diabetes, hypertension or heart
			disease, be sure to consult your doctor or pharmacist before
			purchasing or taking any supplement. While vitamin and mineral
			supplements are widely used and generally considered safe, you may
			wish to check with your doctor or pharmacist before taking these or
			any other dietary supplements. If you plan to use a dietary
			supplement in place of drugs or in combination with any drug, tell
			your health care provider first. Many supplements contain active
			ingredients that have strong biological effects and their safety is
			not always assured in all users. If you have certain health
			conditions and take these products, you may be placing yourself at
			risk.</p>
		<h3>Reversals and Chargebacks</h3>
		<p>We consider Chargebacks and reversals as potential cases of
			fraudulent use of our services and/or theft of services, and will be
			treated as such. We reserve the right to file a complaint with the
			appropriate local and federal authorities to investigate. Be advised
			that all activity and IP address information is being monitored and
			that this information may be used in a civil and/or criminal case(s)
			against a client if there is fraudulent use and or theft of services.</p>
		<h3>Customizing Orders</h3>
		<p>Customer satisfaction is our main priority, and we are always
			interested in making our customers' experience with our products
			enjoyable and convenient. If you would like to request custom
			arrangements for your account, such as bulk orders, and/or ordering
			additional products, just call our customer service representatives
			and we will be happy to discuss your account with you. We cannot
			accommodate every request, but we do our best to accommodate where
			possible. To ensure the highest quality customer care, and to be sure
			that your order is handled correctly, your call will be recorded and
			archived for future reference.</p>
		<h3>Representations</h3>
		<p>You hereby represent and warrant that:</p>
		<p>
			1. You are age eighteen (18) or older.<br /> 2. You have read this
			Agreement and thoroughly understand the terms contained.<br /> 3.
			You further represent that our website has the right to rely upon all
			information and may contact you by email, telephone or postal mail
			for any purpose regarding the use of this website
		</p>
		<h3>ENTIRE AGREEMENT:</h3>
		<p>This Agreement sets forth the entire agreement between the
			parties. You acknowledge and agree that You have reviewed this
			Agreement in its entirety, and every part thereof, and that You
			understand the Agreement. You further acknowledge and agree that You
			have had the opportunity to review this Agreement and otherwise
			consult with Your independent counsel as to the Agreement.</p>
		<footer>
			<a href="javascript:void(0)"
				class="button small green close-popup-link">Close</a>
		</footer>
	</div>
</div>
</section>

<script type="text/javascript">

    var error_scroll = false;
    var order_form_selector = '#form1';

    $(document).ready(function () {


        try {

            $(order_form_selector).submit(function () {
                show_exit = false;
            });

            $(order_form_selector).validate({

                submitHandler: function (form) {
                    show_exit = false;

                    $('.popup-loading-wrapper').show();
                    setTimeout(function () {
                        form.submit();
                    }, 2000);

                },
                invalidHandler: function (event, validator) {

                    error_scroll = true;
                    logging($(order_form_selector));
                    show_exit = true;
                    var errors = validator.numberOfInvalids();
                    if (errors) {

                        $.each($(order_form_selector).find('.form-holder'), function (index, elem) {
                            $(elem).removeClass('has-error').addClass('accept');
                            $(elem).find('input').removeClass('error');
                        });

                    } else {
                        show_exit = false;
                    }
                },
                errorPlacement: function (error, element) {

                    if ($(element).hasClass('error')) {
                        $(element).closest('div[class^="form-holder"]').addClass('has-error').removeClass('accept');
                        $(element).addClass('error');
                        if (error_scroll) {
                            $('html, body').animate({
                                scrollTop: $(element).offset().top - 90
                            }, 500);
                            error_scroll = false;
                        }
                    } else {
                        $(element).closest('div[class^="form-holder"]').removeClass('has-error').addClass('accept');
                        $(element).removeClass('error');
                    }
                },
                success: function (label) {
                },
                rules: {
                    first_name: "required",
                    last_name: "required",
                    address1: "required",
                    city: "required",
                    country: "required",
                    state: "required",
                    zip_code: "required",
                    phone: {
                        required: true,
                        minlength: 10,
                        maxlength: 20
                    },
                    email: {
                        required: true
                    }
                }
            });

        } catch (e) {
            sendJsErrorInTry(order_form_selector, e, 'index');
        }
    });

</script>

<script type="text/javascript">
    $(document).ready(function () {
        $('.slider').slick({
            dots: true,
            autoplay: true,
            autoplaySpeed: 15000,
            adaptiveHeight: true,
            fade: false,
            focusOnSelect: false,
            arrows: false,
            //slidesToScroll: 3,
            slidesToShow: 1,
            responsive: [
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                    }
                }
            ]

        });


        $('.cta').on('click', function () {
            $('html, body').animate({
                scrollTop: "0px"
            }, "slow");
            return false;

        });
    });
</script>


<?php wp_footer();?>
</body>

</html>
